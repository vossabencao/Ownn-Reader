package com.offlinereader

import android.content.Context
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File

/** Text extraction for PDFs (PDFBox-Android). Scanned PDFs without a text layer yield empty text. */
object PdfText {
    @Volatile
    private var inited = false

    fun extract(ctx: Context, file: File): String {
        if (!inited) {
            PDFBoxResourceLoader.init(ctx.applicationContext)
            inited = true
        }
        PDDocument.load(file).use { doc ->
            val st = PDFTextStripper()
            st.setSortByPosition(true)
            st.setPageEnd("\u000c")
            val text = st.getText(doc)
            val pages = text.split('\u000c')
            val sb = StringBuilder()
            pages.forEachIndexed { i, p ->
                if (i == pages.lastIndex && p.isBlank()) return@forEachIndexed
                val lines = p.trim('\n', '\r').split("\n").joinToString("<br>") { TextUtil.esc(it.trimEnd('\r')) }
                sb.append("<p>").append(lines).append("</p>")
                if (i < pages.lastIndex) sb.append("<hr class=\"pb\">")
            }
            if (sb.isEmpty()) sb.append("<p><br></p>")
            return sb.toString()
        }
    }
}
