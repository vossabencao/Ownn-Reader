package com.offlinereader

import org.jsoup.Jsoup
import java.io.IOException

object EpubReader {
    fun toHtml(bytes: ByteArray): String {
        val z = Zip.readAll(bytes)
        val container = Xml.dom(z["META-INF/container.xml"] ?: throw IOException("container.xml ausente")).documentElement
        val opfPath = container.descendants("rootfile").firstOrNull()?.getAttribute("full-path")
            ?.takeIf { it.isNotEmpty() } ?: throw IOException("Arquivo OPF não indicado no EPUB")
        val opf = Xml.dom(z[opfPath] ?: throw IOException("OPF ausente: $opfPath")).documentElement
        val opfDir = opfPath.substringBeforeLast('/', "")

        val manifest = HashMap<String, Pair<String, String>>()
        for (item in opf.descendants("item")) {
            manifest[item.getAttribute("id")] = item.getAttribute("href") to item.getAttribute("media-type")
        }
        val spine = opf.descendants("itemref").map { it.getAttribute("idref") }

        val budget = LongArray(1)
        val sb = StringBuilder()
        var chapters = 0
        for (idref in spine) {
            val (href, type) = manifest[idref] ?: continue
            if (!type.contains("html")) continue
            val path = resolvePath(opfDir, href)
            val data = z[path] ?: continue
            val dir = path.substringBeforeLast('/', "")
            val doc = Jsoup.parse(TextUtil.decode(data))
            for (img in doc.select("img[src]")) {
                val src = img.attr("src")
                if (src.startsWith("data:")) continue
                val uri = Imgs.dataUri(z, resolvePath(dir, src), budget)
                if (uri != null) img.attr("src", uri) else img.remove()
            }
            sb.append("<div class=\"chapter\">").append(doc.body().html()).append("</div><hr class=\"pb\">")
            chapters++
        }
        if (chapters == 0) throw IOException("EPUB sem capítulos legíveis")
        return Sanitizer.clean(sb.toString())
    }
}
