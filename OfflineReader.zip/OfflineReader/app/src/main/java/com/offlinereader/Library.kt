package com.offlinereader

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class FileItem(val uri: Uri, val name: String, val size: Long, val modified: Long) {
    val ext: String get() = FileTypes.ext(name)
}

/** Remembers picked files / folders (SAF persistable grants) and lists them. */
object Library {
    @Volatile
    var dirty = false

    private const val PREFS = "library"
    private const val KEY_TREES = "trees"
    private const val KEY_FILES = "files"

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun trees(c: Context): Set<String> = prefs(c).getStringSet(KEY_TREES, emptySet()) ?: emptySet()
    fun files(c: Context): Set<String> = prefs(c).getStringSet(KEY_FILES, emptySet()) ?: emptySet()

    private fun put(c: Context, key: String, set: Set<String>) {
        prefs(c).edit().putStringSet(key, HashSet(set)).apply()
        dirty = true
    }

    fun addTree(c: Context, uri: Uri) = put(c, KEY_TREES, trees(c) + uri.toString())
    fun removeTree(c: Context, uri: String) = put(c, KEY_TREES, trees(c) - uri)
    fun addFile(c: Context, uri: Uri) = put(c, KEY_FILES, files(c) + uri.toString())
    fun removeFile(c: Context, uri: Uri) = put(c, KEY_FILES, files(c) - uri.toString())

    fun persist(c: Context, uri: Uri, grantFlags: Int) {
        val rw = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        val wanted = (grantFlags and rw).takeIf { it != 0 } ?: Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            c.contentResolver.takePersistableUriPermission(uri, wanted)
        } catch (e: SecurityException) {
            try {
                c.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e2: Exception) {
            }
        } catch (e: Exception) {
        }
    }

    fun release(c: Context, uri: Uri) {
        try {
            c.contentResolver.releasePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (e: Exception) {
        }
    }

    suspend fun scan(c: Context): List<FileItem> = withContext(Dispatchers.IO) {
        val out = LinkedHashMap<String, FileItem>()
        for (f in files(c)) {
            queryItem(c, Uri.parse(f))?.let { out[f] = it }
        }
        for (t in trees(c)) {
            try {
                scanTree(c, Uri.parse(t), out)
            } catch (e: Exception) {
            }
        }
        dirty = false
        out.values.toList()
    }

    private fun queryItem(c: Context, uri: Uri): FileItem? {
        try {
            c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
                if (!cur.moveToFirst()) return null
                val n = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = cur.getColumnIndex(OpenableColumns.SIZE)
                val m = cur.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val name = if (n >= 0) cur.getString(n) else null
                return FileItem(
                    uri,
                    name ?: uri.lastPathSegment ?: "arquivo",
                    if (s >= 0 && !cur.isNull(s)) cur.getLong(s) else 0L,
                    if (m >= 0 && !cur.isNull(m)) cur.getLong(m) else 0L,
                )
            }
        } catch (e: Exception) {
        }
        return null
    }

    private fun scanTree(c: Context, tree: Uri, out: MutableMap<String, FileItem>) {
        val stack = ArrayDeque<String>()
        stack.add(DocumentsContract.getTreeDocumentId(tree))
        var dirs = 0
        val proj = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        )
        while (stack.isNotEmpty() && dirs < 5000 && out.size < 30000) {
            val id = stack.removeLast()
            dirs++
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            c.contentResolver.query(children, proj, null, null, null)?.use { cur ->
                while (cur.moveToNext()) {
                    val docId = cur.getString(0) ?: continue
                    val name = cur.getString(1) ?: continue
                    val mime = cur.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        stack.add(docId)
                        continue
                    }
                    if (FileTypes.ext(name) !in FileTypes.supported) continue
                    val uri = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
                    out[uri.toString()] = FileItem(
                        uri, name,
                        if (cur.isNull(3)) 0L else cur.getLong(3),
                        if (cur.isNull(4)) 0L else cur.getLong(4),
                    )
                }
            }
        }
    }
}
