package com.offlinereader

import java.io.IOException

/** Snapshot of the document being saved, independent of the format it was opened from. */
class Content(
    val strategy: Strategy,
    val ext: String,
    val html: String,
    val text: String,
    val rows: List<List<String>>?,
    val delimiter: Char,
    val source: String? = null,
) {
    companion object {
        fun fromSource(ext: String, src: String): Content {
            val html = when (ext) {
                "md", "markdown" -> DocRenderer.markdownBody(src)
                "html", "htm" -> DocRenderer.htmlBody(src)
                else -> TextUtil.paragraphsHtml(src)
            }
            return Content(Strategy.SOURCE, ext, html, src, null, ',', src)
        }
    }
}

object Exporter {
    /** [fmt] is the target extension: txt, pdf, docx, html, md, csv, tsv. */
    fun toBytes(fmt: String, c: Content, title: String): ByteArray = when (fmt) {
        "txt" -> c.text.toByteArray(Charsets.UTF_8)
        "md" -> (c.source ?: c.text).toByteArray(Charsets.UTF_8)
        "csv" -> Csv.encode(c.rows ?: emptyList(), if (c.delimiter == '\t') ',' else c.delimiter).toByteArray(Charsets.UTF_8)
        "tsv" -> Csv.encode(c.rows ?: emptyList(), '\t').toByteArray(Charsets.UTF_8)
        "html", "htm" ->
            if (c.strategy == Strategy.SOURCE && (c.ext == "html" || c.ext == "htm") && c.source != null)
                c.source.toByteArray(Charsets.UTF_8)
            else wrapHtml(title, c.html).toByteArray(Charsets.UTF_8)
        "pdf" ->
            if ((c.strategy == Strategy.SOURCE && c.ext != "md" && c.ext != "markdown" && c.ext != "html" && c.ext != "htm") ||
                c.strategy == Strategy.TABLE
            ) PdfWriter.fromText(c.text) else PdfWriter.fromHtml(c.html)
        "docx" -> DocxWriter.fromHtml(c.html)
        else -> throw IOException("Formato de saída não suportado: $fmt")
    }

    private fun wrapHtml(title: String, body: String): String =
        "<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>${TextUtil.esc(title)}</title></head><body>\n$body\n</body></html>\n"
}
