package com.offlinereader

import org.w3c.dom.Element
import java.io.IOException

object PptxReader {
    fun toHtml(bytes: ByteArray): String {
        val z = Zip.readAll(bytes)
        val order = slideOrder(z)
        val budget = LongArray(1)
        val sb = StringBuilder()
        for ((idx, path) in order.withIndex()) {
            val data = z[path] ?: continue
            val dir = path.substringBeforeLast('/', "")
            val relPath = dir + "/_rels/" + path.substringAfterLast('/') + ".rels"
            val rels = Xml.rels(z[relPath])
            val tree = Xml.dom(data).documentElement.first("p:cSld")?.first("p:spTree")
            sb.append("<section class=\"slide\">")
            if (tree != null) shapes(tree, z, rels, dir, budget, sb)
            sb.append("</section><div class=\"slidelabel\">Slide ${idx + 1} / ${order.size}</div>")
        }
        if (sb.isEmpty()) throw IOException("Nenhum slide encontrado no .pptx")
        return Sanitizer.clean(sb.toString())
    }

    private fun slideOrder(z: Map<String, ByteArray>): List<String> {
        try {
            val pres = z["ppt/presentation.xml"]
            val rels = Xml.rels(z["ppt/_rels/presentation.xml.rels"])
            if (pres != null) {
                val ids = Xml.dom(pres).documentElement.descendants("sldId").map { it.getAttribute("r:id") }
                val list = ids.mapNotNull { id -> rels[id]?.let { resolvePath("ppt", it) } }.filter { z.containsKey(it) }
                if (list.isNotEmpty()) return list
            }
        } catch (e: Exception) {
        }
        val re = Regex("ppt/slides/slide(\\d+)\\.xml")
        return z.keys.mapNotNull { k -> re.matchEntire(k)?.let { it.groupValues[1].toInt() to k } }
            .sortedBy { it.first }.map { it.second }
    }

    private fun shapes(
        parent: Element, z: Map<String, ByteArray>, rels: Map<String, String>,
        baseDir: String, budget: LongArray, sb: StringBuilder,
    ) {
        for (e in parent.elems()) {
            when (e.tagName) {
                "p:sp" -> {
                    val ph = e.first("p:nvSpPr")?.first("p:nvPr")?.first("p:ph")
                    val type = ph?.getAttribute("type") ?: ""
                    val title = type == "title" || type == "ctrTitle"
                    val tx = e.first("p:txBody") ?: continue
                    for (para in tx.elems()) {
                        if (para.tagName != "a:p") continue
                        val inner = StringBuilder()
                        paraRuns(para, inner)
                        if (inner.isEmpty()) continue
                        val pPr = para.first("a:pPr")
                        val bullet = !title && pPr != null && (pPr.first("a:buChar") != null || pPr.first("a:buAutoNum") != null)
                        val lvl = pPr?.getAttribute("lvl")?.toIntOrNull() ?: 0
                        if (title) {
                            sb.append("<h2>").append(inner.toString()).append("</h2>")
                        } else {
                            sb.append("<p style=\"margin-left:").append(lvl * 24).append("px\">")
                            if (bullet) sb.append("\u2022 ")
                            sb.append(inner.toString()).append("</p>")
                        }
                    }
                }
                "p:pic" -> for (blip in e.descendants("blip")) {
                    val t = rels[blip.getAttribute("r:embed")] ?: continue
                    val uri = Imgs.dataUri(z, resolvePath(baseDir, t), budget)
                    if (uri != null) sb.append("<p><img src=\"").append(uri).append("\"></p>")
                }
                "p:grpSp" -> shapes(e, z, rels, baseDir, budget, sb)
                "p:graphicFrame" -> {
                    val tbl = e.descendants("tbl").firstOrNull()
                    if (tbl != null) table(tbl, sb)
                }
            }
        }
    }

    private fun table(tbl: Element, sb: StringBuilder) {
        sb.append("<table>")
        for (tr in tbl.elems()) {
            if (tr.tagName != "a:tr") continue
            sb.append("<tr>")
            for (tc in tr.elems()) {
                if (tc.tagName != "a:tc") continue
                sb.append("<td>")
                val tx = tc.first("a:txBody")
                if (tx != null) {
                    var firstPara = true
                    for (para in tx.elems()) {
                        if (para.tagName != "a:p") continue
                        if (!firstPara) sb.append("<br>")
                        firstPara = false
                        paraRuns(para, sb)
                    }
                }
                sb.append("</td>")
            }
            sb.append("</tr>")
        }
        sb.append("</table>")
    }

    private fun paraRuns(para: Element, out: StringBuilder) {
        for (r in para.elems()) {
            when (r.tagName) {
                "a:r" -> {
                    val t = r.first("a:t")?.textContent ?: ""
                    if (t.isEmpty()) continue
                    var s = TextUtil.esc(t)
                    val rp = r.first("a:rPr")
                    if (rp?.getAttribute("b") == "1") s = "<b>$s</b>"
                    if (rp?.getAttribute("i") == "1") s = "<i>$s</i>"
                    val u = rp?.getAttribute("u") ?: ""
                    if (u.isNotEmpty() && u != "none") s = "<u>$s</u>"
                    out.append(s)
                }
                "a:br" -> out.append("<br>")
                "a:fld" -> out.append(TextUtil.esc(r.first("a:t")?.textContent ?: ""))
            }
        }
    }
}
