package com.offlinereader

object FileTypes {
    val groups: Map<String, Set<String>> = mapOf(
        "pdf" to setOf("pdf"),
        "word" to setOf("doc", "docx"),
        "slides" to setOf("pptx"),
        "books" to setOf("epub"),
        "text" to setOf("txt", "md", "markdown"),
        "web" to setOf("html", "htm"),
        "sheets" to setOf("csv", "tsv"),
        "enc" to setOf("enc"),
    )
    val supported: Set<String> = groups.values.flatten().toSet()

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase()
    fun group(ext: String): String = groups.entries.firstOrNull { ext in it.value }?.key ?: "other"

    fun badgeColor(ext: String): Int = when (group(ext)) {
        "pdf" -> 0xFFD93025.toInt()
        "word" -> 0xFF1A73E8.toInt()
        "slides" -> 0xFFE8710A.toInt()
        "books" -> 0xFF188038.toInt()
        "text" -> 0xFF5F6368.toInt()
        "web" -> 0xFF00897B.toInt()
        "sheets" -> 0xFF0B8043.toInt()
        "enc" -> 0xFF202124.toInt()
        else -> 0xFF80868B.toInt()
    }
}
