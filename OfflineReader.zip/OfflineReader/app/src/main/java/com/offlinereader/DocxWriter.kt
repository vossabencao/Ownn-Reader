package com.offlinereader

import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Writes a minimal, valid .docx from HTML: paragraphs, headings, bold/italic/underline/strike/highlight,
 * lists (as text bullets/numbers) and simple tables. Images and page layout are NOT preserved.
 */
object DocxWriter {
    private val BLOCKS = setOf(
        "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "pre", "blockquote", "ul", "ol", "table",
        "section", "article", "hr", "tr", "center", "header", "footer", "nav", "aside", "main", "figure",
    )

    private data class Fmt(
        val b: Boolean = false, val i: Boolean = false, val u: Boolean = false,
        val s: Boolean = false, val hl: Boolean = false, val size: Int = 0,
    )

    private const val CONTENT_TYPES =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
            "</Types>"

    private const val RELS =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
            "</Relationships>"

    fun fromHtml(html: String): ByteArray {
        val body = Jsoup.parseBodyFragment(html).body()
        val sb = StringBuilder()
        blocks(body, sb)
        if (sb.isEmpty()) sb.append("<w:p/>")
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>" +
            sb +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            put("[Content_Types].xml", CONTENT_TYPES)
            put("_rels/.rels", RELS)
            put("word/document.xml", doc)
        }
        return bos.toByteArray()
    }

    private fun blocks(parent: Element, sb: StringBuilder) {
        val pending = ArrayList<Node>()
        fun flush() {
            if (pending.any { !(it is TextNode && it.isBlank) }) sb.append(para(pending, 0, "", false, 0))
            pending.clear()
        }
        for (n in parent.childNodes()) {
            if (n is Element && n.tagName() in BLOCKS) {
                flush()
                block(n, sb)
            } else pending.add(n)
        }
        flush()
    }

    private fun block(e: Element, sb: StringBuilder) {
        when (val t = e.tagName()) {
            "ul", "ol" -> list(e, sb, 0)
            "table" -> table(e, sb)
            "hr" -> if (e.hasClass("pb")) sb.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            "tr" -> {}
            "h1", "h2", "h3", "h4", "h5", "h6" -> sb.append(para(e.childNodes(), t[1] - '0', "", false, 0))
            "pre" -> sb.append(para(e.childNodes(), 0, "", true, 0))
            "li" -> sb.append(para(e.childNodes(), 0, "\u2022 ", false, 360))
            else ->
                if (e.children().any { it.tagName() in BLOCKS }) blocks(e, sb)
                else sb.append(para(e.childNodes(), 0, "", false, 0))
        }
    }

    private fun list(l: Element, sb: StringBuilder, depth: Int) {
        val ordered = l.tagName() == "ol"
        var n = l.attr("start").toIntOrNull() ?: 1
        for (li in l.children()) {
            if (li.tagName() != "li") continue
            val inline = li.childNodes().filter { !(it is Element && (it.tagName() == "ul" || it.tagName() == "ol")) }
            val prefix = if (ordered) "${n++}. " else "\u2022 "
            sb.append(para(inline, 0, prefix, false, (depth + 1) * 360))
            for (sub in li.children()) if (sub.tagName() == "ul" || sub.tagName() == "ol") list(sub, sb, depth + 1)
        }
    }

    private fun table(t: Element, sb: StringBuilder) {
        val rows = t.select("tr").filter { r -> r.children().any { it.tagName() == "td" || it.tagName() == "th" } }
        if (rows.isEmpty()) return
        val cols = rows.maxOf { r -> r.children().count { it.tagName() == "td" || it.tagName() == "th" } }.coerceAtLeast(1)
        val w = 9000 / cols
        sb.append("<w:tbl><w:tblPr><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders>")
        for (side in listOf("top", "left", "bottom", "right", "insideH", "insideV")) {
            sb.append("<w:").append(side).append(" w:val=\"single\" w:sz=\"4\" w:space=\"0\" w:color=\"999999\"/>")
        }
        sb.append("</w:tblBorders></w:tblPr><w:tblGrid>")
        repeat(cols) { sb.append("<w:gridCol w:w=\"").append(w).append("\"/>") }
        sb.append("</w:tblGrid>")
        for (tr in rows) {
            sb.append("<w:tr>")
            for (td in tr.children()) {
                if (td.tagName() != "td" && td.tagName() != "th") continue
                val cell = StringBuilder()
                blocks(td, cell)
                if (cell.isEmpty()) cell.append("<w:p/>")
                sb.append("<w:tc><w:tcPr><w:tcW w:w=\"").append(w).append("\" w:type=\"dxa\"/></w:tcPr>")
                    .append(cell.toString()).append("</w:tc>")
            }
            sb.append("</w:tr>")
        }
        sb.append("</w:tbl><w:p/>")
    }

    private fun para(nodes: List<Node>, heading: Int, prefix: String, pre: Boolean, indent: Int): String {
        val runs = StringBuilder()
        val size = when (heading) {
            0 -> 0
            1 -> 40
            2 -> 32
            3 -> 28
            else -> 24
        }
        val base = Fmt(b = heading > 0, size = size)
        if (prefix.isNotEmpty()) runs.append(run(prefix, base))
        inline(nodes, base, pre, runs)
        val ppr = if (indent > 0) "<w:pPr><w:ind w:left=\"$indent\"/></w:pPr>" else ""
        return "<w:p>$ppr$runs</w:p>"
    }

    private fun inline(nodes: List<Node>, f: Fmt, pre: Boolean, out: StringBuilder) {
        for (n in nodes) {
            if (n is TextNode) {
                if (pre) {
                    n.wholeText.split("\n").forEachIndexed { i, l ->
                        if (i > 0) out.append("<w:r><w:br/></w:r>")
                        if (l.isNotEmpty()) out.append(run(l, f))
                    }
                } else {
                    val t = n.text()
                    if (t.isNotEmpty()) out.append(run(t, f))
                }
            } else if (n is Element) {
                when (n.tagName()) {
                    "br" -> out.append("<w:r><w:br/></w:r>")
                    "img", "script", "style" -> {}
                    "b", "strong" -> inline(n.childNodes(), f.copy(b = true), pre, out)
                    "i", "em" -> inline(n.childNodes(), f.copy(i = true), pre, out)
                    "u", "ins" -> inline(n.childNodes(), f.copy(u = true), pre, out)
                    "s", "strike", "del" -> inline(n.childNodes(), f.copy(s = true), pre, out)
                    "mark" -> inline(n.childNodes(), f.copy(hl = true), pre, out)
                    else -> inline(n.childNodes(), f, pre || n.tagName() == "pre", out)
                }
            }
        }
    }

    private fun run(text: String, f: Fmt): String {
        val rpr = StringBuilder()
        if (f.b) rpr.append("<w:b/>")
        if (f.i) rpr.append("<w:i/>")
        if (f.s) rpr.append("<w:strike/>")
        if (f.size > 0) rpr.append("<w:sz w:val=\"").append(f.size).append("\"/>")
        if (f.hl) rpr.append("<w:highlight w:val=\"yellow\"/>")
        if (f.u) rpr.append("<w:u w:val=\"single\"/>")
        val pr = if (rpr.isEmpty()) "" else "<w:rPr>$rpr</w:rPr>"
        return "<w:r>$pr<w:t xml:space=\"preserve\">${xml(text)}</w:t></w:r>"
    }

    private fun xml(s: String): String {
        val sb = StringBuilder(s.length + 16)
        for (ch in s) {
            when (ch) {
                '&' -> sb.append("&amp;")
                '<' -> sb.append("&lt;")
                '>' -> sb.append("&gt;")
                '"' -> sb.append("&quot;")
                else -> if ((ch.code >= 0x20 || ch == '\t' || ch == '\n' || ch == '\r') && ch != '\uFFFE' && ch != '\uFFFF') sb.append(ch)
            }
        }
        return sb.toString()
    }
}
