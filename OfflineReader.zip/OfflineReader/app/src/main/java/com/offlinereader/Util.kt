package com.offlinereader

import android.text.TextUtils
import android.util.Base64
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.safety.Safelist
import org.w3c.dom.Element
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

object Zip {
    /** Reads every file entry into memory with size caps (zip-bomb guard). */
    fun readAll(bytes: ByteArray, maxEntry: Int = 60 * 1024 * 1024, maxTotal: Long = 250L * 1024 * 1024): Map<String, ByteArray> {
        val out = LinkedHashMap<String, ByteArray>()
        var total = 0L
        ZipInputStream(ByteArrayInputStream(bytes)).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.isDirectory) continue
                val bos = ByteArrayOutputStream()
                val buf = ByteArray(16384)
                var size = 0
                while (true) {
                    val r = zin.read(buf)
                    if (r < 0) break
                    size += r
                    if (size > maxEntry) throw IOException("Entrada do ZIP grande demais: ${e.name}")
                    bos.write(buf, 0, r)
                }
                total += size
                if (total > maxTotal) throw IOException("Arquivo ZIP descompactado grande demais")
                out[e.name] = bos.toByteArray()
            }
        }
        return out
    }
}

object Xml {
    fun dom(bytes: ByteArray): org.w3c.dom.Document {
        val s = String(bytes, Charsets.ISO_8859_1)
        if (s.contains("<!DOCTYPE", ignoreCase = true) || s.contains("<!ENTITY", ignoreCase = true)) {
            throw IOException("XML com DTD não é suportado")
        }
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = false
        return f.newDocumentBuilder().parse(ByteArrayInputStream(bytes))
    }

    fun rels(b: ByteArray?): Map<String, String> {
        if (b == null) return emptyMap()
        val out = HashMap<String, String>()
        for (r in dom(b).documentElement.elems()) {
            if (r.tagName.substringAfter(':') == "Relationship") out[r.getAttribute("Id")] = r.getAttribute("Target")
        }
        return out
    }
}

fun Element.elems(): List<Element> {
    val out = ArrayList<Element>()
    var n = firstChild
    while (n != null) {
        if (n is Element) out.add(n)
        n = n.nextSibling
    }
    return out
}

fun Element.first(tag: String): Element? = elems().firstOrNull { it.tagName == tag }

fun Element.descendants(local: String): List<Element> {
    val nl = getElementsByTagName("*")
    val out = ArrayList<Element>()
    for (i in 0 until nl.length) {
        val e = nl.item(i) as Element
        if (e.tagName.substringAfter(':') == local) out.add(e)
    }
    return out
}

fun resolvePath(baseDir: String, href: String): String {
    var h = href.substringBefore('#').substringBefore('?')
    h = try {
        URLDecoder.decode(h.replace("+", "%2B"), "UTF-8")
    } catch (e: Exception) {
        h
    }
    val full = if (h.startsWith("/")) h.trimStart('/') else if (baseDir.isEmpty()) h else "$baseDir/$h"
    val parts = ArrayList<String>()
    for (seg in full.split('/')) {
        when (seg) {
            "", "." -> {}
            ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
            else -> parts.add(seg)
        }
    }
    return parts.joinToString("/")
}

object Imgs {
    private val MIME = mapOf(
        "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg",
        "gif" to "image/gif", "bmp" to "image/bmp", "webp" to "image/webp",
    )

    /** Returns a data: URI or null (unsupported type, too big, or total budget exceeded). */
    fun dataUri(zip: Map<String, ByteArray>, path: String, budget: LongArray): String? {
        val data = zip[path] ?: return null
        val mime = MIME[FileTypes.ext(path)] ?: return null
        if (data.size > 4_000_000 || budget[0] + data.size > 40_000_000L) return null
        budget[0] += data.size.toLong()
        return "data:$mime;base64," + Base64.encodeToString(data, Base64.NO_WRAP)
    }
}

object Sanitizer {
    private val safelist: Safelist = Safelist.relaxed()
        .addTags(
            "mark", "section", "article", "header", "footer", "nav", "aside", "main",
            "figure", "figcaption", "hr", "details", "summary", "center", "s", "del", "ins"
        )
        .addAttributes(":all", "class", "id", "style", "dir", "lang", "title")
        .addAttributes("td", "align", "colspan", "rowspan")
        .addAttributes("th", "align", "colspan", "rowspan")
        .addAttributes("ol", "start", "type")
        .addProtocols("img", "src", "data")
        .preserveRelativeLinks(true)

    fun clean(html: String): String =
        Jsoup.clean(html, "", safelist, Document.OutputSettings().prettyPrint(false))
}

object TextUtil {
    fun esc(s: CharSequence): String = TextUtils.htmlEncode(s.toString())

    fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (e: CharacterCodingException) {
            String(b, Charset.forName("windows-1252"))
        }
    }

    fun looksLikeText(b: ByteArray): Boolean {
        val n = minOf(b.size, 8000)
        for (i in 0 until n) if (b[i].toInt() == 0) return false
        return true
    }

    fun paragraphsHtml(text: String): String {
        val sb = StringBuilder()
        for (line in text.split("\n")) {
            val l = line.trimEnd('\r')
            sb.append("<p>").append(if (l.isEmpty()) "<br>" else esc(l)).append("</p>")
        }
        return sb.toString()
    }

    fun htmlToPlain(html: String): String {
        val d = Jsoup.parseBodyFragment(html)
        d.outputSettings().prettyPrint(false)
        d.select("br").after("\n")
        d.select("p,div,h1,h2,h3,h4,h5,h6,li,tr,pre,blockquote,section").after("\n")
        d.select("td,th").after("\t")
        return d.body().wholeText().replace(Regex("\n{3,}"), "\n\n").trim('\n')
    }
}

object Csv {
    private fun pick(c: Int, s: Int, t: Int): Char = if (t > c && t > s) '\t' else if (s > c) ';' else ','

    fun detectDelimiter(text: String): Char {
        var comma = 0
        var semi = 0
        var tab = 0
        var inQ = false
        for (ch in text.take(8192)) {
            if (ch == '"') {
                inQ = !inQ
            } else if (!inQ) {
                when (ch) {
                    ',' -> comma++
                    ';' -> semi++
                    '\t' -> tab++
                    '\n' -> if (comma + semi + tab > 0) return pick(comma, semi, tab)
                }
            }
        }
        return pick(comma, semi, tab)
    }

    fun parse(text: String, delim: Char, maxRows: Int): Pair<List<List<String>>, Boolean> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val f = StringBuilder()
        var inQ = false
        var truncated = false
        var cells = 0
        var i = 0
        val n = text.length

        fun endRow() {
            row.add(f.toString())
            f.setLength(0)
            cells += row.size
            rows.add(row)
            row = ArrayList()
        }

        while (i < n) {
            if (rows.size >= maxRows || cells > 800_000) {
                truncated = true
                break
            }
            val ch = text[i]
            if (inQ) {
                if (ch == '"') {
                    if (i + 1 < n && text[i + 1] == '"') {
                        f.append('"')
                        i++
                    } else inQ = false
                } else f.append(ch)
            } else if (ch == '"' && f.isEmpty()) {
                inQ = true
            } else if (ch == delim) {
                row.add(f.toString())
                f.setLength(0)
            } else if (ch == '\r') {
                if (i + 1 < n && text[i + 1] == '\n') i++
                endRow()
            } else if (ch == '\n') {
                endRow()
            } else f.append(ch)
            i++
        }
        if (!truncated && (f.isNotEmpty() || row.isNotEmpty())) endRow()
        val width = rows.maxOfOrNull { it.size } ?: 0
        val norm = rows.map { r -> if (r.size < width) r + List(width - r.size) { "" } else r }
        return Pair(norm, truncated)
    }

    fun encode(rows: List<List<String>>, delim: Char): String {
        val sb = StringBuilder()
        for (r in rows) {
            for ((k, v) in r.withIndex()) {
                if (k > 0) sb.append(delim)
                sb.append(quote(v, delim))
            }
            sb.append('\n')
        }
        return sb.toString()
    }

    private fun quote(v: String, d: Char): String =
        if (v.any { it == d || it == '"' || it == '\n' || it == '\r' }) "\"" + v.replace("\"", "\"\"") + "\"" else v
}

object TableHtml {
    fun colName(index: Int): String {
        var i = index + 1
        val sb = StringBuilder()
        while (i > 0) {
            val m = (i - 1) % 26
            sb.insert(0, ('A'.code + m).toChar())
            i = (i - 1) / 26
        }
        return sb.toString()
    }

    fun sheet(rows: List<List<String>>): String {
        val cols = rows.maxOfOrNull { it.size } ?: 0
        val sb = StringBuilder("<table><thead><tr><th class=\"corner\"></th>")
        for (c in 0 until cols) sb.append("<th>").append(colName(c)).append("</th>")
        sb.append("</tr></thead><tbody>")
        rows.forEachIndexed { i, r ->
            sb.append("<tr><th class=\"rn\">").append(i + 1).append("</th>")
            for (c in 0 until cols) sb.append("<td>").append(TextUtil.esc(r.getOrElse(c) { "" })).append("</td>")
            sb.append("</tr>")
        }
        sb.append("</tbody></table>")
        return sb.toString()
    }

    fun plain(rows: List<List<String>>): String {
        val sb = StringBuilder("<table>")
        for (r in rows) {
            sb.append("<tr>")
            for (c in r) sb.append("<td>").append(TextUtil.esc(c)).append("</td>")
            sb.append("</tr>")
        }
        sb.append("</table>")
        return sb.toString()
    }
}
