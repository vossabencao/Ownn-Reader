package com.offlinereader

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract

private const val RW = Intent.FLAG_GRANT_READ_URI_PERMISSION or
    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION

/** Opens the system file picker (multiple files) asking for persistable read+write grants. */
class PickDocuments : ActivityResultContract<Unit, Intent?>() {
    override fun createIntent(context: Context, input: Unit): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(RW)
        }

    override fun parseResult(resultCode: Int, intent: Intent?): Intent? =
        if (resultCode == Activity.RESULT_OK) intent else null
}

/** Opens the system folder picker with persistable read+write grants. */
class PickFolder : ActivityResultContract<Unit, Intent?>() {
    override fun createIntent(context: Context, input: Unit): Intent =
        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply { addFlags(RW) }

    override fun parseResult(resultCode: Int, intent: Intent?): Intent? =
        if (resultCode == Activity.RESULT_OK) intent else null
}

/** Input: (mime, suggested file name). Output: the result intent (data = created document Uri). */
class CreateDoc : ActivityResultContract<Pair<String, String>, Intent?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = input.first
            putExtra(Intent.EXTRA_TITLE, input.second)
            addFlags(RW)
        }

    override fun parseResult(resultCode: Int, intent: Intent?): Intent? =
        if (resultCode == Activity.RESULT_OK) intent else null
}
