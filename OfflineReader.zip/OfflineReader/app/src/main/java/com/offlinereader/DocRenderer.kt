package com.offlinereader

import org.commonmark.ext.gfm.strikethrough.StrikethroughExtension
import org.commonmark.ext.gfm.tables.TablesExtension
import org.commonmark.parser.Parser
import org.commonmark.renderer.html.HtmlRenderer
import org.jsoup.Jsoup
import java.io.IOException

enum class Strategy { SOURCE, TABLE, RICH }
enum class Look { WRITER, PLAIN, CALC, IMPRESS }

class TableData(val rows: List<List<String>>, val delimiter: Char)

class Rendered(
    val body: String,
    val strategy: Strategy,
    val look: Look,
    val source: String? = null,
    val table: TableData? = null,
    val readOnlyReason: String? = null,
)

object DocRenderer {
    private const val MAX_ROWS = 20000
    private const val MAX_SOURCE_CHARS = 3_000_000

    private val mdExt = listOf(TablesExtension.create(), StrikethroughExtension.create())
    private val mdParser = Parser.builder().extensions(mdExt).build()
    private val mdRenderer = HtmlRenderer.builder().extensions(mdExt).build()

    fun markdownBody(src: String): String = Sanitizer.clean(mdRenderer.render(mdParser.parse(src)))
    fun htmlBody(src: String): String = Sanitizer.clean(Jsoup.parse(src).body().html())
    fun plainBody(src: String): String = TextUtil.esc(src)

    fun renderText(ext: String, src: String): Rendered {
        val reason = if (src.length > MAX_SOURCE_CHARS) "Arquivo grande demais para o editor de texto nativo (somente leitura)." else null
        return when (ext) {
            "md", "markdown" -> Rendered(markdownBody(src), Strategy.SOURCE, Look.WRITER, source = src, readOnlyReason = reason)
            "html", "htm" -> Rendered(htmlBody(src), Strategy.SOURCE, Look.WRITER, source = src, readOnlyReason = reason)
            else -> Rendered(plainBody(src), Strategy.SOURCE, Look.PLAIN, source = src, readOnlyReason = reason)
        }
    }

    fun renderTable(ext: String, text: String): Rendered {
        val delim = if (ext == "tsv") '\t' else Csv.detectDelimiter(text)
        val (rows, truncated) = Csv.parse(text, delim, MAX_ROWS)
        return Rendered(
            TableHtml.sheet(rows), Strategy.TABLE, Look.CALC, table = TableData(rows, delim),
            readOnlyReason = if (truncated) "Planilha grande: exibição truncada em $MAX_ROWS linhas. Edição desativada para não perder dados." else null,
        )
    }

    fun render(ext: String, bytes: ByteArray): Rendered = when (ext) {
        "txt", "md", "markdown", "html", "htm" -> renderText(ext, TextUtil.decode(bytes))
        "csv", "tsv" -> renderTable(ext, TextUtil.decode(bytes))
        "docx" -> Rendered(DocxReader.toHtml(bytes), Strategy.RICH, Look.WRITER)
        "doc" -> Rendered(DocReader.toHtml(bytes), Strategy.RICH, Look.WRITER)
        "pptx" -> Rendered(PptxReader.toHtml(bytes), Strategy.RICH, Look.IMPRESS)
        "epub" -> Rendered(EpubReader.toHtml(bytes), Strategy.RICH, Look.WRITER)
        else -> throw IOException("Formato não suportado: .$ext")
    }
}

/** Builds the full HTML page (Writer / Calc / Impress look) shown inside the WebView. */
object Template {
    private const val CSS = """
html,body{margin:0;padding:0}
body{background:#d9dce1;color:#000;-webkit-text-size-adjust:100%}
body.writer #doc,body.plain #doc{box-sizing:border-box;background:#fff;width:794px;max-width:calc(100% - 16px);margin:12px auto;padding:72px 80px;min-height:1123px;box-shadow:0 0 0 1px #c3c7cd,0 2px 8px rgba(0,0,0,.25);font-family:"Liberation Serif","Times New Roman",Times,serif;font-size:12pt;line-height:1.35;overflow-wrap:anywhere}
@media (max-width:820px){body.writer #doc,body.plain #doc{padding:28px 18px;min-height:0}}
body.plain #doc{font-family:"Liberation Mono","Courier New",monospace;font-size:11pt;white-space:pre-wrap}
#doc h1{font-size:20pt;margin:.6em 0 .3em}
#doc h2{font-size:16pt;margin:.6em 0 .3em}
#doc h3{font-size:14pt;margin:.6em 0 .3em}
#doc h4,#doc h5,#doc h6{font-size:12pt;margin:.6em 0 .3em}
#doc p{margin:0 0 .6em}
#doc img{max-width:100%;height:auto}
#doc table{border-collapse:collapse;max-width:100%}
body.writer #doc td,body.writer #doc th{border:1px solid #888;padding:3px 6px;vertical-align:top}
#doc pre,#doc code{font-family:"Liberation Mono","Courier New",monospace}
#doc pre{background:#f4f4f4;padding:8px;white-space:pre-wrap}
#doc blockquote{margin:.6em 0 .6em 1em;padding-left:.8em;border-left:3px solid #bbb;color:#444}
#doc hr.pb{border:0;border-top:1px dashed #9aa;margin:24px 0}
mark{background:#ff0}
body.calc{background:#fff;font-family:"Liberation Sans",Arial,Helvetica,sans-serif;font-size:11pt}
body.calc #doc{width:max-content;min-width:100%}
.sheet table{border-collapse:collapse}
.sheet th{background:#e6e9ee;border:1px solid #b9bec7;font-weight:normal;color:#333;padding:2px 8px;min-width:60px;position:sticky;top:0;z-index:2}
.sheet th.rn{left:0;top:auto;z-index:1;min-width:34px;text-align:center}
.sheet th.corner{left:0;z-index:3}
.sheet td{border:1px solid #d0d4da;padding:2px 8px;min-width:80px;height:22px;white-space:pre}
.sheet td:focus{outline:2px solid #2a6ebb;outline-offset:-2px}
body.impress{background:#5f6368}
.deck{padding:12px}
.slide{box-sizing:border-box;background:#fff;width:960px;max-width:100%;aspect-ratio:16/9;margin:0 auto 6px;padding:5%;box-shadow:0 2px 8px rgba(0,0,0,.4);font-family:"Liberation Sans",Arial,sans-serif;font-size:16px;line-height:1.3}
.slide h2{margin:0 0 .5em;font-size:1.6em}
.slidelabel{color:#dcdcdc;text-align:center;font:12px sans-serif;margin:0 0 16px}
#doc[contenteditable=true]{outline:none}
"""

    private const val JS = """
function setEditable(on){var d=document.getElementById('doc');if(STRAT==='TABLE'){var c=document.querySelectorAll('#doc td');for(var i=0;i<c.length;i++){c[i].contentEditable=on?'true':'false';}}else{d.contentEditable=on?'true':'false';if(on){d.focus();}}}
function getHtml(){return document.getElementById('doc').innerHTML;}
function colName(i){var s='';i++;while(i>0){var m=(i-1)%26;s=String.fromCharCode(65+m)+s;i=Math.floor((i-1)/26);}return s;}
function cellText(c){var t=c.innerText;while(t.length&&t.charAt(t.length-1)==='\n'){t=t.slice(0,-1);}return t;}
function getRows(){var rows=document.querySelectorAll('#doc tbody tr');var out=[];for(var i=0;i<rows.length;i++){var cells=rows[i].cells;var r=[];for(var j=1;j<cells.length;j++){r.push(cellText(cells[j]));}out.push(r);}return JSON.stringify(out);}
function notify(){if(window.OfflineBridge){OfflineBridge.onInput();}}
function addRow(){var tb=document.querySelector('#doc tbody');if(!tb)return;var n=tb.rows.length;var tr=tb.insertRow(-1);var h=document.createElement('th');h.className='rn';h.textContent=String(n+1);tr.appendChild(h);var hr=document.querySelector('#doc thead tr');var cols=hr?hr.cells.length-1:1;for(var i=0;i<cols;i++){var td=tr.insertCell(-1);td.contentEditable='true';}notify();}
function addCol(){var hr=document.querySelector('#doc thead tr');if(!hr)return;var th=document.createElement('th');th.textContent=colName(hr.cells.length-1);hr.appendChild(th);var rows=document.querySelector('#doc tbody').rows;for(var i=0;i<rows.length;i++){var td=rows[i].insertCell(-1);td.contentEditable='true';}notify();}
function selText(){return String(window.getSelection());}
document.addEventListener('input',notify);
"""

    fun page(body: String, look: Look, strategy: Strategy): String {
        val cls = when (look) {
            Look.WRITER -> "writer"
            Look.PLAIN -> "plain"
            Look.CALC -> "calc"
            Look.IMPRESS -> "impress"
        }
        val docCls = when (look) {
            Look.WRITER, Look.PLAIN -> "page"
            Look.CALC -> "sheet"
            Look.IMPRESS -> "deck"
        }
        return "<!DOCTYPE html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
            "<style>" + CSS + "</style></head><body class=\"$cls\"><div id=\"doc\" class=\"$docCls\">" +
            body + "</div><script>var STRAT='${strategy.name}';" + JS + "</script></body></html>"
    }
}
