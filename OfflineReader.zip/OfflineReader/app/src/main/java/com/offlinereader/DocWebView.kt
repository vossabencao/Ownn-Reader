package com.offlinereader

import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.WebView

/**
 * WebView whose native text-selection toolbar (long-press, drag handles, copy/cut/paste/select all)
 * gets extra items appended. Items are (id, label); clicks go to [onSelectionItem].
 */
class DocWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : WebView(context, attrs) {

    var selectionItems: List<Pair<Int, String>> = emptyList()
    var onSelectionItem: ((Int) -> Boolean)? = null

    override fun startActionMode(callback: ActionMode.Callback?): ActionMode? =
        super.startActionMode(wrap(callback))

    override fun startActionMode(callback: ActionMode.Callback?, type: Int): ActionMode? =
        super.startActionMode(wrap(callback), type)

    private fun wrap(cb: ActionMode.Callback?): ActionMode.Callback? = when (cb) {
        null -> null
        is ActionMode.Callback2 -> Wrapper2(cb)
        else -> Wrapper(cb)
    }

    private fun addItems(menu: Menu) {
        for ((id, label) in selectionItems) {
            if (menu.findItem(id) == null) {
                menu.add(Menu.NONE, id, 200, label).setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER)
            }
        }
    }

    private fun handle(mode: ActionMode, item: MenuItem): Boolean {
        if (selectionItems.none { it.first == item.itemId }) return false
        val handled = onSelectionItem?.invoke(item.itemId) ?: false
        if (handled) mode.finish()
        return handled
    }

    private inner class Wrapper(val d: ActionMode.Callback) : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            val r = d.onCreateActionMode(mode, menu)
            addItems(menu)
            return r
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            val r = d.onPrepareActionMode(mode, menu)
            addItems(menu)
            return r
        }

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean =
            handle(mode, item) || d.onActionItemClicked(mode, item)

        override fun onDestroyActionMode(mode: ActionMode) = d.onDestroyActionMode(mode)
    }

    private inner class Wrapper2(val d: ActionMode.Callback2) : ActionMode.Callback2() {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            val r = d.onCreateActionMode(mode, menu)
            addItems(menu)
            return r
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            val r = d.onPrepareActionMode(mode, menu)
            addItems(menu)
            return r
        }

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean =
            handle(mode, item) || d.onActionItemClicked(mode, item)

        override fun onDestroyActionMode(mode: ActionMode) = d.onDestroyActionMode(mode)

        override fun onGetContentRect(mode: ActionMode, view: View, outRect: Rect) =
            d.onGetContentRect(mode, view, outRect)
    }
}
