package com.offlinereader

import java.nio.ByteBuffer
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Container format ("OFRENC" v1):
 *   magic(6) | version(1) | salt(16) | iv(12) | pbkdf2Iterations(int32 BE) | AES-256-GCM ciphertext+tag
 * The whole 39-byte header is authenticated as GCM AAD. Key = PBKDF2WithHmacSHA256(passphrase, salt).
 */
object Crypto {
    class WrongPassphrase : Exception("Senha incorreta ou arquivo corrompido")

    private val MAGIC = "OFRENC".toByteArray(Charsets.US_ASCII)
    private const val VERSION = 1
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val ITERATIONS = 600_000
    private const val HEADER_LEN = 6 + 1 + SALT_LEN + IV_LEN + 4
    private const val TAG_BITS = 128

    fun isEncrypted(data: ByteArray): Boolean {
        if (data.size < HEADER_LEN + TAG_BITS / 8) return false
        for (i in MAGIC.indices) if (data[i] != MAGIC[i]) return false
        return true
    }

    fun encrypt(plain: ByteArray, pass: CharArray): ByteArray {
        val rnd = SecureRandom()
        val salt = ByteArray(SALT_LEN).also { rnd.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { rnd.nextBytes(it) }
        val header = ByteBuffer.allocate(HEADER_LEN)
            .put(MAGIC).put(VERSION.toByte()).put(salt).put(iv).putInt(ITERATIONS).array()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, derive(pass, salt, ITERATIONS), GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(header)
        return header + cipher.doFinal(plain)
    }

    fun decrypt(data: ByteArray, pass: CharArray): ByteArray {
        if (!isEncrypted(data)) throw IllegalArgumentException("Não é um arquivo criptografado por este app")
        val bb = ByteBuffer.wrap(data, 0, HEADER_LEN)
        bb.position(6)
        val version = bb.get().toInt()
        if (version != VERSION) throw IllegalArgumentException("Versão de criptografia não suportada: $version")
        val salt = ByteArray(SALT_LEN).also { bb.get(it) }
        val iv = ByteArray(IV_LEN).also { bb.get(it) }
        val iter = bb.getInt()
        if (iter < 100_000 || iter > 5_000_000) throw IllegalArgumentException("Parâmetros de criptografia inválidos")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, derive(pass, salt, iter), GCMParameterSpec(TAG_BITS, iv))
        cipher.updateAAD(data, 0, HEADER_LEN)
        try {
            return cipher.doFinal(data, HEADER_LEN, data.size - HEADER_LEN)
        } catch (e: AEADBadTagException) {
            throw WrongPassphrase()
        }
    }

    private fun derive(pass: CharArray, salt: ByteArray, iter: Int): SecretKeySpec {
        val spec = PBEKeySpec(pass, salt, iter, 256)
        try {
            val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            return SecretKeySpec(f.generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}
