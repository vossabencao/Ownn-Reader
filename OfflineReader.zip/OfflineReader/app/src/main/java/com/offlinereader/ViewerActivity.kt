package com.offlinereader

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputType
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONTokener
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume

class ViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NEW = "new_document"
        private const val BASE = "https://offline.local/"
        private const val ID_HIGHLIGHT = 9001
        private const val ID_SHARE = 9002
        private const val ID_FIND = 9003
        private const val MAX_BYTES = 150L * 1024 * 1024
    }

    private enum class Mode { NONE, WEB, PDF }
    private class Format(val label: String, val ext: String, val mime: String)

    private lateinit var toolbar: MaterialToolbar
    private lateinit var web: DocWebView
    private lateinit var sourceEdit: EditText
    private lateinit var pdfList: RecyclerView
    private lateinit var progress: ProgressBar
    private lateinit var editBar: HorizontalScrollView
    private lateinit var editBarInner: LinearLayout
    private lateinit var findBar: View
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView

    private var uri: Uri? = null
    private var displayName = "Sem título"
    private var ext = ""
    private var passphrase: CharArray? = null
    private var rendered: Rendered? = null
    private var currentSource: String? = null
    private var mode = Mode.NONE
    private var editing = false
    private var dirty = false
    private var suppressWatcher = false
    private var menuRef: Menu? = null
    private var findSpan: BackgroundColorSpan? = null

    private var pdfFile: File? = null
    private var pdfFd: ParcelFileDescriptor? = null
    private var pdfRenderer: PdfRenderer? = null
    private var pdfExecutor: ExecutorService? = null
    private var pdfScope: CoroutineScope? = null

    private var pendingFormat: Format? = null
    private var pendingPass: CharArray? = null
    private var pendingAfter: (() -> Unit)? = null

    private val createDoc = registerForActivityResult(CreateDoc()) { intent ->
        val u = intent?.data
        if (u != null) {
            finishSaveAs(u, intent.flags)
        } else {
            pendingFormat = null
            pendingPass?.fill('\u0000')
            pendingPass = null
            pendingAfter = null
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewer)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        web = findViewById(R.id.webView)
        sourceEdit = findViewById(R.id.sourceEdit)
        pdfList = findViewById(R.id.pdfList)
        progress = findViewById(R.id.progress)
        editBar = findViewById(R.id.editBar)
        editBarInner = findViewById(R.id.editBarInner)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        findCount = findViewById(R.id.findCount)
        pdfList.layoutManager = LinearLayoutManager(this)

        configureWeb()
        configureSource()
        configureFind()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    findBar.visibility == View.VISIBLE -> closeFind()
                    editing -> requestExitEdit()
                    else -> finish()
                }
            }
        })

        if (intent.getBooleanExtra(EXTRA_NEW, false)) {
            startNew()
        } else {
            val u = intent.data
            if (u == null) {
                finish()
                return
            }
            uri = u
            displayName = queryName(u)
            load()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    override fun onDestroy() {
        pdfScope?.cancel()
        val ex = pdfExecutor
        val r = pdfRenderer
        val fd = pdfFd
        val f = pdfFile
        if (ex != null) {
            ex.execute {
                try {
                    r?.close()
                    fd?.close()
                } catch (e: Exception) {
                }
                f?.delete()
            }
            ex.shutdown()
        } else {
            f?.delete()
        }
        passphrase?.fill('\u0000')
        web.destroy()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- setup

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private inner class Bridge {
        @JavascriptInterface
        fun onInput() {
            runOnUiThread {
                if (editing && !dirty) {
                    dirty = true
                    updateMenu()
                }
            }
        }
    }

    private fun configureWeb() {
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        web.addJavascriptInterface(Bridge(), "OfflineBridge")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url.toString()
                // allow only in-document anchors; block everything else (the app is offline anyway)
                return !(u.startsWith(BASE) && u.contains('#'))
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (editing) view.evaluateJavascript("setEditable(true)", null)
            }
        }
        web.setFindListener { active, total, _ ->
            findCount.text = if (total == 0) "0" else "${active + 1}/$total"
        }
        web.onSelectionItem = { id -> handleSelectionItem(id) }
        refreshSelectionItems()
    }

    private fun refreshSelectionItems() {
        web.selectionItems = buildList {
            if (editing && rendered?.strategy == Strategy.RICH) add(ID_HIGHLIGHT to "Destacar")
            add(ID_SHARE to "Compartilhar")
            add(ID_FIND to "Buscar no documento")
        }
    }

    private fun handleSelectionItem(id: Int): Boolean {
        when (id) {
            ID_HIGHLIGHT -> web.evaluateJavascript("document.execCommand('hiliteColor',false,'#ffff00')", null)
            ID_SHARE -> lifecycleScope.launch {
                val t = evalString("selText()")
                if (t.isNotEmpty()) shareText(t)
            }
            ID_FIND -> lifecycleScope.launch { openFind(evalString("selText()")) }
            else -> return false
        }
        return true
    }

    private fun shareText(t: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
        startActivity(Intent.createChooser(i, null))
    }

    private fun configureSource() {
        sourceEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (!suppressWatcher && editing && !dirty) {
                    dirty = true
                    updateMenu()
                }
            }
        })
        sourceEdit.customSelectionActionModeCallback = object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                menu.add(Menu.NONE, ID_SHARE, 200, "Compartilhar")
                menu.add(Menu.NONE, ID_FIND, 201, "Buscar no documento")
                return true
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                val a = minOf(sourceEdit.selectionStart, sourceEdit.selectionEnd).coerceAtLeast(0)
                val b = maxOf(sourceEdit.selectionStart, sourceEdit.selectionEnd).coerceAtLeast(0)
                val t = sourceEdit.text.substring(a, b)
                return when (item.itemId) {
                    ID_SHARE -> {
                        if (t.isNotEmpty()) shareText(t)
                        mode.finish()
                        true
                    }
                    ID_FIND -> {
                        openFind(t)
                        mode.finish()
                        true
                    }
                    else -> false
                }
            }

            override fun onDestroyActionMode(mode: ActionMode) {}
        }
    }

    private fun configureFind() {
        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = doFind(s?.toString() ?: "", true, fresh = true)
        })
        findInput.setOnEditorActionListener { _, _, _ ->
            doFind(findInput.text.toString(), true, fresh = false)
            true
        }
        findViewById<Button>(R.id.findNext).setOnClickListener { doFind(findInput.text.toString(), true, fresh = false) }
        findViewById<Button>(R.id.findPrev).setOnClickListener { doFind(findInput.text.toString(), false, fresh = false) }
        findViewById<Button>(R.id.findClose).setOnClickListener { closeFind() }
    }

    // ---------------------------------------------------------------- find

    private fun openFind(prefill: String) {
        if (mode == Mode.PDF) {
            toast("Use o modo texto para buscar em PDF.")
            return
        }
        findBar.visibility = View.VISIBLE
        if (prefill.isNotEmpty()) findInput.setText(prefill)
        findInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        findBar.visibility = View.GONE
        web.clearMatches()
        clearSourceHighlight()
        findCount.text = ""
        hideKeyboard()
    }

    private fun clearSourceHighlight() {
        findSpan?.let { sourceEdit.text.removeSpan(it) }
        findSpan = null
    }

    private fun doFind(q: String, forward: Boolean, fresh: Boolean) {
        if (mode == Mode.PDF) return
        if (sourceEdit.visibility == View.VISIBLE) {
            findInSource(q, forward, fresh)
            return
        }
        if (q.isEmpty()) {
            web.clearMatches()
            findCount.text = ""
            return
        }
        if (fresh) web.findAllAsync(q) else web.findNext(forward)
    }

    private fun findInSource(q: String, forward: Boolean, fresh: Boolean) {
        clearSourceHighlight()
        val t = sourceEdit.text
        if (q.isEmpty()) {
            findCount.text = ""
            return
        }
        var count = 0
        var i = t.indexOf(q, 0, true)
        while (i >= 0) {
            count++
            i = t.indexOf(q, i + q.length, true)
        }
        if (count == 0) {
            findCount.text = "0"
            return
        }
        val cur = sourceEdit.selectionEnd.coerceAtLeast(0)
        var pos = when {
            fresh -> t.indexOf(q, minOf(sourceEdit.selectionStart.coerceAtLeast(0), t.length), true)
            forward -> t.indexOf(q, cur, true)
            else -> t.lastIndexOf(q, (sourceEdit.selectionStart - 1).coerceAtLeast(0), true)
        }
        if (pos < 0) pos = if (forward || fresh) t.indexOf(q, 0, true) else t.lastIndexOf(q, t.length, true)
        if (pos < 0) return
        val span = BackgroundColorSpan(Color.YELLOW)
        t.setSpan(span, pos, pos + q.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        findSpan = span
        suppressWatcher = true
        sourceEdit.setSelection(pos)
        suppressWatcher = false
        sourceEdit.bringPointIntoView(pos)
        findCount.text = "$count"
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(window.decorView.windowToken, 0)
    }

    // ---------------------------------------------------------------- loading

    private fun queryName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val n = c.getString(0)
                    if (!n.isNullOrEmpty()) return n
                }
            }
        } catch (e: Exception) {
        }
        return u.lastPathSegment?.substringAfterLast('/') ?: "arquivo"
    }

    private fun readBytes(u: Uri): ByteArray {
        val ins = contentResolver.openInputStream(u) ?: throw IOException("Não foi possível abrir o arquivo")
        ins.use {
            val bos = ByteArrayOutputStream()
            val buf = ByteArray(65536)
            var total = 0L
            while (true) {
                val r = it.read(buf)
                if (r < 0) break
                total += r
                if (total > MAX_BYTES) throw IOException("Arquivo maior que 150 MB")
                bos.write(buf, 0, r)
            }
            return bos.toByteArray()
        }
    }

    private fun writeBytes(u: Uri, data: ByteArray) {
        val os = contentResolver.openOutputStream(u, "wt") ?: throw IOException("Não foi possível gravar no destino")
        os.use { it.write(data) }
    }

    private suspend fun askPassphrase(): CharArray? = suspendCancellableCoroutine<CharArray?> { cont ->
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            hint = "Senha / passphrase"
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("Arquivo criptografado")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Abrir") { _, _ ->
                val c = CharArray(input.length())
                input.text.getChars(0, c.size, c, 0)
                if (cont.isActive) cont.resume(c)
            }
            .setNegativeButton("Cancelar") { _, _ -> if (cont.isActive) cont.resume(null) }
            .create()
        cont.invokeOnCancellation { dlg.dismiss() }
        dlg.show()
    }

    private fun load() {
        val u = uri ?: return
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val raw = withContext(Dispatchers.IO) { readBytes(u) }
                var data = raw
                var name = displayName
                if (name.endsWith(".enc", true) || Crypto.isEncrypted(raw)) {
                    while (true) {
                        progress.visibility = View.GONE
                        val pass = askPassphrase() ?: run {
                            finish()
                            return@launch
                        }
                        progress.visibility = View.VISIBLE
                        try {
                            data = withContext(Dispatchers.IO) { Crypto.decrypt(raw, pass) }
                            passphrase = pass
                            break
                        } catch (e: Crypto.WrongPassphrase) {
                            pass.fill('\u0000')
                            toast("Senha incorreta ou arquivo corrompido.")
                        }
                    }
                    if (name.endsWith(".enc", true)) name = name.dropLast(4)
                }
                displayName = if (passphrase != null) name else displayName
                ext = FileTypes.ext(name)
                if (ext == "pdf") {
                    withContext(Dispatchers.IO) { openPdf(data) }
                    showPdfPages()
                } else {
                    ext = effectiveExt(data)
                    val r = withContext(Dispatchers.IO) { DocRenderer.render(ext, data) }
                    showRendered(r)
                }
            } catch (e: OutOfMemoryError) {
                fail("Memória insuficiente para abrir este arquivo.")
            } catch (e: Exception) {
                fail("Não foi possível abrir: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    private fun effectiveExt(data: ByteArray): String = when {
        ext in FileTypes.supported && ext != "enc" -> ext
        TextUtil.looksLikeText(data) -> "txt"
        else -> throw IOException("Formato não suportado: .$ext")
    }

    private fun startNew() {
        displayName = "Sem título"
        ext = "new"
        showRendered(Rendered("<p><br></p>", Strategy.RICH, Look.WRITER))
        startEditing()
    }

    private fun fail(msg: String) {
        progress.visibility = View.GONE
        AlertDialog.Builder(this)
            .setTitle("Erro")
            .setMessage(msg)
            .setPositiveButton("OK") { _, _ -> if (mode == Mode.NONE) finish() }
            .setOnCancelListener { if (mode == Mode.NONE) finish() }
            .show()
    }

    // ---------------------------------------------------------------- display

    private fun showRendered(r: Rendered) {
        rendered = r
        currentSource = r.source
        mode = Mode.WEB
        dirty = false
        pdfList.visibility = View.GONE
        sourceEdit.visibility = View.GONE
        web.visibility = View.VISIBLE
        web.loadDataWithBaseURL(BASE, Template.page(r.body, r.look, r.strategy), "text/html", "UTF-8", null)
        progress.visibility = View.GONE
        refreshSelectionItems()
        updateMenu()
    }

    private fun openPdf(data: ByteArray) {
        val f = File(cacheDir, "view-${System.nanoTime()}.pdf")
        f.writeBytes(data)
        pdfFile = f
        val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        pdfFd = fd
        pdfRenderer = PdfRenderer(fd)
        val ex = Executors.newSingleThreadExecutor()
        pdfExecutor = ex
        pdfScope = CoroutineScope(SupervisorJob() + ex.asCoroutineDispatcher())
    }

    private fun showPdfPages() {
        val r = pdfRenderer ?: return
        val scope = pdfScope ?: return
        mode = Mode.PDF
        web.visibility = View.GONE
        sourceEdit.visibility = View.GONE
        pdfList.visibility = View.VISIBLE
        pdfList.adapter = PdfPagesAdapter(r, scope) { pdfList.width }
        progress.visibility = View.GONE
        updateMenu()
    }

    private fun showPdfText(thenEdit: Boolean) {
        val f = pdfFile ?: return
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val body = withContext(Dispatchers.IO) { PdfText.extract(this@ViewerActivity, f) }
                showRendered(Rendered(body, Strategy.RICH, Look.WRITER))
                if (thenEdit) startEditing()
            } catch (e: OutOfMemoryError) {
                fail("Memória insuficiente para extrair o texto do PDF.")
            } catch (e: Exception) {
                fail("Não foi possível extrair o texto do PDF: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    // ---------------------------------------------------------------- menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_viewer, menu)
        menuRef = menu
        updateMenu()
        return true
    }

    private fun updateMenu() {
        supportActionBar?.title = displayName
        supportActionBar?.subtitle = when {
            mode == Mode.PDF -> "Páginas · somente leitura"
            editing -> if (dirty) "Editando · alterado" else "Editando"
            else -> "Somente leitura"
        }
        val m = menuRef ?: return
        val loaded = mode != Mode.NONE
        m.findItem(R.id.action_edit)?.let {
            it.isVisible = loaded
            it.setIcon(if (editing) R.drawable.ic_done else R.drawable.ic_edit)
            it.title = if (editing) "Concluir edição" else "Editar"
        }
        m.findItem(R.id.action_find)?.isVisible = loaded
        m.findItem(R.id.action_save)?.let {
            it.isVisible = mode == Mode.WEB && (editing || dirty)
            it.title = if (rendered?.strategy == Strategy.RICH || uri == null) "Salvar cópia editada…" else "Salvar"
        }
        m.findItem(R.id.action_save_as)?.isVisible = mode == Mode.WEB
        m.findItem(R.id.action_toggle_pdf)?.let {
            it.isVisible = pdfRenderer != null
            it.title = if (mode == Mode.PDF) "Modo texto (selecionar/editar)" else "Modo páginas"
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_edit -> if (editing) requestExitEdit() else enterEdit()
            R.id.action_find -> if (findBar.visibility == View.VISIBLE) closeFind() else openFind("")
            R.id.action_save -> {
                val r = rendered
                if (r == null || r.strategy == Strategy.RICH || uri == null) showSaveAs() else saveOverwrite { }
            }
            R.id.action_save_as -> showSaveAs()
            R.id.action_toggle_pdf -> {
                if (editing) toast("Conclua a edição antes de trocar de modo.")
                else if (mode == Mode.PDF) showPdfText(false) else showPdfPages()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------------------------------------------------------- editing

    private fun enterEdit() {
        if (mode == Mode.PDF) {
            showPdfText(true)
            toast("PDF: edição ocorre sobre o texto extraído; ao salvar é gerado um novo arquivo.")
            return
        }
        val r = rendered ?: return
        val reason = r.readOnlyReason
        if (reason != null) {
            toast(reason)
            return
        }
        startEditing()
    }

    private fun startEditing() {
        val r = rendered ?: return
        editing = true
        dirty = false
        refreshSelectionItems()
        if (r.strategy == Strategy.SOURCE) {
            suppressWatcher = true
            sourceEdit.setText(currentSource ?: "")
            suppressWatcher = false
            sourceEdit.visibility = View.VISIBLE
            web.visibility = View.GONE
        } else {
            web.evaluateJavascript("setEditable(true)", null)
        }
        buildEditBar()
        editBar.visibility = if (r.strategy == Strategy.SOURCE) View.GONE else View.VISIBLE
        updateMenu()
    }

    private fun exec(cmd: String, value: String? = null) {
        val v = if (value == null) "null" else "'$value'"
        web.evaluateJavascript("document.execCommand('$cmd',false,$v)", null)
    }

    private fun buildEditBar() {
        editBarInner.removeAllViews()
        val r = rendered ?: return
        fun btn(label: String, action: () -> Unit) {
            val b = MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle)
            b.text = label
            b.isAllCaps = false
            b.isFocusable = false
            b.isFocusableInTouchMode = false
            b.setOnClickListener { action() }
            editBarInner.addView(b)
        }
        when (r.strategy) {
            Strategy.RICH -> {
                btn("↶") { exec("undo") }
                btn("↷") { exec("redo") }
                btn("B") { exec("bold") }
                btn("I") { exec("italic") }
                btn("U") { exec("underline") }
                btn("S") { exec("strikeThrough") }
                btn("Título") { exec("formatBlock", "H1") }
                btn("Subtítulo") { exec("formatBlock", "H2") }
                btn("Normal") { exec("formatBlock", "P") }
                btn("• Lista") { exec("insertUnorderedList") }
                btn("1. Lista") { exec("insertOrderedList") }
                btn("Destacar") { exec("hiliteColor", "#ffff00") }
                btn("Limpar fmt.") { exec("removeFormat") }
            }
            Strategy.TABLE -> {
                btn("+ Linha") { web.evaluateJavascript("addRow()", null) }
                btn("+ Coluna") { web.evaluateJavascript("addCol()", null) }
            }
            Strategy.SOURCE -> {}
        }
    }

    private fun requestExitEdit() {
        if (!dirty) {
            exitEdit()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Salvar alterações?")
            .setPositiveButton("Salvar") { _, _ ->
                val r = rendered
                if (r == null || r.strategy == Strategy.RICH || uri == null) {
                    pendingAfter = { exitEdit() }
                    showSaveAs()
                } else {
                    saveOverwrite { ok -> if (ok) exitEdit() }
                }
            }
            .setNegativeButton("Descartar") { _, _ -> discardAndExit() }
            .setNeutralButton("Cancelar", null)
            .show()
    }

    private fun endEditUi() {
        editing = false
        dirty = false
        editBar.visibility = View.GONE
        closeFind()
        refreshSelectionItems()
        hideKeyboard()
    }

    private fun exitEdit() {
        val r = rendered ?: return
        endEditUi()
        if (r.strategy == Strategy.SOURCE) {
            val text = sourceEdit.text.toString()
            val e = ext
            lifecycleScope.launch {
                val nr = withContext(Dispatchers.IO) { DocRenderer.renderText(e, text) }
                showRendered(nr)
            }
        } else {
            web.evaluateJavascript("setEditable(false)", null)
            updateMenu()
        }
    }

    private fun discardAndExit() {
        val r = rendered ?: return
        endEditUi()
        showRendered(r)
    }

    // ---------------------------------------------------------------- JS bridge helpers

    private fun decodeJsString(res: String?): String {
        if (res == null || res == "null") return ""
        return (JSONTokener(res).nextValue() as? String) ?: ""
    }

    private suspend fun evalString(js: String): String = suspendCancellableCoroutine { cont ->
        web.evaluateJavascript(js) { res -> if (cont.isActive) cont.resume(decodeJsString(res)) }
    }

    private suspend fun fetchRows(): List<List<String>> {
        val s = evalString("getRows()")
        if (s.isEmpty()) return emptyList()
        val arr = JSONArray(s)
        val rows = ArrayList<List<String>>()
        for (i in 0 until arr.length()) {
            val ra = arr.getJSONArray(i)
            val row = ArrayList<String>()
            for (j in 0 until ra.length()) row.add(ra.getString(j))
            rows.add(row)
        }
        return rows
    }

    private suspend fun gatherContent(): Content {
        val r = rendered ?: throw IllegalStateException("Nenhum documento aberto")
        return when (r.strategy) {
            Strategy.SOURCE -> {
                val src = if (sourceEdit.visibility == View.VISIBLE) sourceEdit.text.toString() else (currentSource ?: "")
                val e = ext
                withContext(Dispatchers.IO) { Content.fromSource(e, src) }
            }
            Strategy.TABLE -> {
                val rows = fetchRows()
                Content(Strategy.TABLE, ext, TableHtml.plain(rows), Csv.encode(rows, '\t'), rows, r.table?.delimiter ?: ',')
            }
            Strategy.RICH -> {
                val html = evalString("getHtml()")
                val e = ext
                withContext(Dispatchers.IO) { Content(Strategy.RICH, e, html, TextUtil.htmlToPlain(html), null, ',') }
            }
        }
    }

    // ---------------------------------------------------------------- saving

    private fun saveOverwrite(onDone: (Boolean) -> Unit) {
        val r = rendered
        val u = uri
        if (r == null || u == null || r.strategy == Strategy.RICH) {
            onDone(false)
            return
        }
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val plain: ByteArray = if (r.strategy == Strategy.SOURCE) {
                    sourceEdit.text.toString().toByteArray(Charsets.UTF_8)
                } else {
                    Csv.encode(fetchRows(), r.table?.delimiter ?: ',').toByteArray(Charsets.UTF_8)
                }
                val pass = passphrase
                withContext(Dispatchers.IO) {
                    val out = if (pass != null) Crypto.encrypt(plain, pass) else plain
                    writeBytes(u, out)
                }
                dirty = false
                updateMenu()
                toast("Salvo.")
                onDone(true)
            } catch (e: Exception) {
                AlertDialog.Builder(this@ViewerActivity)
                    .setTitle("Não foi possível salvar no arquivo original")
                    .setMessage("${e.message ?: e.javaClass.simpleName}\n\nUse “Salvar como…” para gravar uma cópia.")
                    .setPositiveButton("OK", null)
                    .show()
                onDone(false)
            } finally {
                progress.visibility = View.GONE
            }
        }
    }

    private fun displayBase(): String {
        val n = displayName.removeSuffix(".enc")
        val b = n.substringBeforeLast('.', n)
        return b.ifEmpty { "documento" }
    }

    private fun availableFormats(): List<Format> {
        val txt = Format("Texto (.txt)", "txt", "text/plain")
        val pdf = Format("PDF (.pdf)", "pdf", "application/pdf")
        val docx = Format("Word (.docx)", "docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
        val html = Format("HTML (.html)", "html", "text/html")
        val list = ArrayList<Format>()
        when (ext) {
            "md", "markdown" -> list.add(Format("Markdown (.md)", "md", "text/markdown"))
            "csv" -> list.add(Format("CSV (.csv)", "csv", "text/csv"))
            "tsv" -> list.add(Format("TSV (.tsv)", "tsv", "text/tab-separated-values"))
        }
        val preferred = when (ext) {
            "docx", "doc", "epub", "pptx" -> "docx"
            "pdf" -> "pdf"
            else -> "txt"
        }
        val rest = listOf(txt, pdf, docx, html).sortedBy { if (it.ext == preferred) 0 else 1 }
        list.addAll(rest)
        return list
    }

    private fun showSaveAs() {
        val formats = availableFormats()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@ViewerActivity, android.R.layout.simple_spinner_dropdown_item, formats.map { it.label })
        }
        val enc = CheckBox(this).apply { text = "Criptografar com senha (AES-256-GCM)" }
        val pwType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val p1 = EditText(this).apply { hint = "Senha / passphrase (mín. 8)"; inputType = pwType; visibility = View.GONE }
        val p2 = EditText(this).apply { hint = "Repita a senha"; inputType = pwType; visibility = View.GONE }
        enc.setOnCheckedChangeListener { _, on ->
            p1.visibility = if (on) View.VISIBLE else View.GONE
            p2.visibility = if (on) View.VISIBLE else View.GONE
        }
        box.addView(spinner)
        box.addView(enc)
        box.addView(p1)
        box.addView(p2)

        val dlg = AlertDialog.Builder(this)
            .setTitle("Salvar como")
            .setView(box)
            .setPositiveButton("Salvar", null)
            .setNegativeButton("Cancelar") { _, _ -> pendingAfter = null }
            .create()
        dlg.setOnShowListener {
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val fmt = formats[spinner.selectedItemPosition]
                var pass: CharArray? = null
                if (enc.isChecked) {
                    val a = p1.text.toString()
                    val b = p2.text.toString()
                    if (a.length < 8) {
                        p1.error = "Mínimo de 8 caracteres"
                        return@setOnClickListener
                    }
                    if (a != b) {
                        p2.error = "As senhas não coincidem"
                        return@setOnClickListener
                    }
                    pass = a.toCharArray()
                }
                pendingFormat = fmt
                pendingPass = pass
                dlg.dismiss()
                val suffix = if (uri != null) " (editado)" else ""
                val name = displayBase() + suffix + "." + fmt.ext + if (pass != null) ".enc" else ""
                createDoc.launch(Pair(if (pass != null) "application/octet-stream" else fmt.mime, name))
            }
        }
        dlg.show()
    }

    private fun finishSaveAs(target: Uri, flags: Int) {
        val fmt = pendingFormat ?: return
        val pass = pendingPass
        val after = pendingAfter
        pendingFormat = null
        pendingPass = null
        pendingAfter = null
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val content = gatherContent()
                val title = displayBase()
                withContext(Dispatchers.IO) {
                    val raw = Exporter.toBytes(fmt.ext, content, title)
                    val out = if (pass != null) Crypto.encrypt(raw, pass) else raw
                    writeBytes(target, out)
                }
                Library.persist(this@ViewerActivity, target, flags)
                Library.addFile(this@ViewerActivity, target)
                dirty = false
                updateMenu()
                toast("Arquivo salvo.")
                after?.invoke()
            } catch (e: Exception) {
                fail("Falha ao salvar: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                pass?.fill('\u0000')
                progress.visibility = View.GONE
            }
        }
    }
}
