package com.offlinereader

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.ChipGroup
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import kotlinx.coroutines.launch
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: FileAdapter
    private lateinit var emptyView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var summary: TextView

    private var all: List<FileItem> = emptyList()
    private var query = ""
    private var group = "all"
    private var dateFilter = R.id.date_all
    private var sort = R.id.sort_date_desc

    private val chipGroups = mapOf(
        R.id.chip_all to "all", R.id.chip_pdf to "pdf", R.id.chip_word to "word",
        R.id.chip_slides to "slides", R.id.chip_books to "books", R.id.chip_text to "text",
        R.id.chip_web to "web", R.id.chip_sheets to "sheets", R.id.chip_enc to "enc",
    )

    private val pickFiles = registerForActivityResult(PickDocuments()) { intent ->
        if (intent != null) handlePicked(intent)
    }

    private val pickFolder = registerForActivityResult(PickFolder()) { intent ->
        val u = intent?.data
        if (intent != null && u != null) {
            Library.persist(this, u, intent.flags)
            Library.addTree(this, u)
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        // remove leftovers of decrypted/temporary PDFs from a previous run
        cacheDir.listFiles()?.filter { it.name.startsWith("view-") }?.forEach { it.delete() }

        emptyView = findViewById(R.id.empty)
        progress = findViewById(R.id.progress)
        summary = findViewById(R.id.summary)

        adapter = FileAdapter({ open(it) }, { itemMenu(it) })
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        findViewById<ChipGroup>(R.id.chips).setOnCheckedStateChangeListener { _, ids ->
            group = chipGroups[ids.firstOrNull()] ?: "all"
            applyFilters()
        }

        findViewById<ExtendedFloatingActionButton>(R.id.fab_new).setOnClickListener {
            startActivity(Intent(this, ViewerActivity::class.java).putExtra(ViewerActivity.EXTRA_NEW, true))
        }

        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (Library.dirty) refresh()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val sv = menu.findItem(R.id.action_search).actionView as SearchView
        sv.queryHint = "Buscar por nome"
        sv.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String): Boolean = true
            override fun onQueryTextChange(q: String): Boolean {
                query = q
                applyFilters()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.sort_name_asc, R.id.sort_name_desc, R.id.sort_date_desc, R.id.sort_date_asc,
            R.id.sort_size_desc, R.id.sort_size_asc, R.id.sort_type -> {
                sort = item.itemId
                item.isChecked = true
                applyFilters()
            }
            R.id.date_all, R.id.date_today, R.id.date_7, R.id.date_30, R.id.date_year -> {
                dateFilter = item.itemId
                item.isChecked = true
                applyFilters()
            }
            R.id.action_add_files -> pickFiles.launch(Unit)
            R.id.action_add_folder -> pickFolder.launch(Unit)
            R.id.action_folders -> showFolders()
            R.id.action_refresh -> refresh()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun handlePicked(intent: Intent) {
        val uris = ArrayList<android.net.Uri>()
        intent.clipData?.let { cd ->
            for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri)
        }
        intent.data?.let { if (it !in uris) uris.add(it) }
        for (u in uris) {
            Library.persist(this, u, intent.flags)
            Library.addFile(this, u)
        }
        refresh()
    }

    private fun open(item: FileItem) {
        startActivity(Intent(this, ViewerActivity::class.java).setData(item.uri))
    }

    private fun itemMenu(item: FileItem) {
        val removable = Library.files(this).contains(item.uri.toString())
        val labels = if (removable) arrayOf("Abrir", "Remover da biblioteca") else arrayOf("Abrir")
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(labels) { _, i ->
                when (i) {
                    0 -> open(item)
                    1 -> {
                        Library.removeFile(this, item.uri)
                        refresh()
                    }
                }
            }
            .show()
    }

    private fun showFolders() {
        val trees = Library.trees(this).toList()
        if (trees.isEmpty()) {
            Toast.makeText(this, "Nenhuma pasta adicionada.", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = trees.map { android.net.Uri.parse(it).lastPathSegment ?: it }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Toque numa pasta para removê-la")
            .setItems(labels) { _, i ->
                Library.release(this, android.net.Uri.parse(trees[i]))
                Library.removeTree(this, trees[i])
                refresh()
            }
            .setNegativeButton("Fechar", null)
            .show()
    }

    private fun refresh() {
        progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            all = Library.scan(this@MainActivity)
            progress.visibility = View.GONE
            applyFilters()
        }
    }

    private fun startOfToday(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private fun applyFilters() {
        val q = query.trim().lowercase()
        val now = System.currentTimeMillis()
        val day = 24L * 60 * 60 * 1000
        val minTime = when (dateFilter) {
            R.id.date_today -> startOfToday()
            R.id.date_7 -> now - 7 * day
            R.id.date_30 -> now - 30 * day
            R.id.date_year -> Calendar.getInstance().also {
                it.set(Calendar.DAY_OF_YEAR, 1)
                it.set(Calendar.HOUR_OF_DAY, 0)
                it.set(Calendar.MINUTE, 0)
                it.set(Calendar.SECOND, 0)
                it.set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            else -> 0L
        }
        val filtered = all.filter {
            (group == "all" || FileTypes.group(it.ext) == group) &&
                (q.isEmpty() || it.name.lowercase().contains(q)) &&
                (minTime == 0L || it.modified >= minTime)
        }
        val sorted = when (sort) {
            R.id.sort_name_asc -> filtered.sortedBy { it.name.lowercase() }
            R.id.sort_name_desc -> filtered.sortedByDescending { it.name.lowercase() }
            R.id.sort_date_asc -> filtered.sortedBy { it.modified }
            R.id.sort_size_desc -> filtered.sortedByDescending { it.size }
            R.id.sort_size_asc -> filtered.sortedBy { it.size }
            R.id.sort_type -> filtered.sortedWith(compareBy({ it.ext }, { it.name.lowercase() }))
            else -> filtered.sortedByDescending { it.modified }
        }
        adapter.submitList(sorted)
        summary.text = "${sorted.size} de ${all.size} arquivos"
        emptyView.visibility = if (sorted.isEmpty()) View.VISIBLE else View.GONE
    }
}
