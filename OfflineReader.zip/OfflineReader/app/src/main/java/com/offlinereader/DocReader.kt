package com.offlinereader

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.charset.Charset

private fun u16(b: ByteArray, o: Int): Int = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
private fun i32(b: ByteArray, o: Int): Int =
    (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
        ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

/** Minimal OLE2 / Compound File Binary reader (v3 and v4 sectors). */
class Ole(private val d: ByteArray) {
    private class Entry(val name: String, val type: Int, val start: Int, val size: Long)

    private val secSize: Int
    private val miniSize: Int
    private val miniCutoff: Int
    private val fat: IntArray
    private val miniFat: IntArray
    private val entries: List<Entry>
    private val miniStream: ByteArray

    init {
        if (d.size < 512 || i32(d, 0) != 0xE011CFD0.toInt() || i32(d, 4) != 0xE11AB1A1.toInt()) {
            throw IOException("Não é um arquivo OLE2 (.doc do Word 97-2003)")
        }
        val shift = u16(d, 0x1E)
        if (shift != 9 && shift != 12) throw IOException("Tamanho de setor OLE2 inválido")
        secSize = 1 shl shift
        miniSize = 1 shl u16(d, 0x20)
        miniCutoff = i32(d, 0x38)

        val fatSectors = ArrayList<Int>()
        for (i in 0 until 109) {
            val s = i32(d, 0x4C + 4 * i)
            if (s >= 0) fatSectors.add(s)
        }
        var dif = i32(d, 0x44)
        var guard = 0
        while (dif >= 0 && guard++ < 10000) {
            val off = secOffset(dif)
            if (off < 0 || off + secSize > d.size) break
            for (i in 0 until secSize / 4 - 1) {
                val s = i32(d, off + 4 * i)
                if (s >= 0) fatSectors.add(s)
            }
            dif = i32(d, off + secSize - 4)
        }

        val perSector = secSize / 4
        fat = IntArray(fatSectors.size * perSector) { -1 }
        var k = 0
        for (s in fatSectors) {
            val off = secOffset(s)
            if (off < 0 || off + secSize > d.size) {
                k += perSector
                continue
            }
            for (j in 0 until perSector) fat[k++] = i32(d, off + 4 * j)
        }

        val dir = readChain(i32(d, 0x30))
        val list = ArrayList<Entry>()
        var e = 0
        while (e + 128 <= dir.size) {
            val nameLen = u16(dir, e + 64)
            val name = if (nameLen in 2..64) String(dir, e, nameLen - 2, Charsets.UTF_16LE) else ""
            val type = dir[e + 66].toInt() and 0xFF
            list.add(Entry(name, type, i32(dir, e + 116), i32(dir, e + 120).toLong() and 0xFFFFFFFFL))
            e += 128
        }
        entries = list

        val root = list.firstOrNull { it.type == 5 }
        miniStream = if (root != null) {
            val raw = readChain(root.start)
            if (raw.size > root.size) raw.copyOf(root.size.toInt()) else raw
        } else ByteArray(0)

        val mf = readChain(i32(d, 0x3C))
        miniFat = IntArray(mf.size / 4) { i32(mf, it * 4) }
    }

    private fun secOffset(s: Int): Int {
        val v = (s.toLong() + 1) * secSize
        return if (v >= 0 && v <= d.size.toLong()) v.toInt() else -1
    }

    private fun readChain(start: Int): ByteArray {
        val out = ByteArrayOutputStream()
        var s = start
        var n = 0
        while (s >= 0 && n++ <= fat.size) {
            val off = secOffset(s)
            if (off < 0) break
            val len = minOf(secSize, d.size - off)
            if (len <= 0) break
            out.write(d, off, len)
            s = if (s < fat.size) fat[s] else -2
        }
        return out.toByteArray()
    }

    private fun readMini(start: Int, size: Int): ByteArray {
        val out = ByteArrayOutputStream()
        var s = start
        var n = 0
        while (s >= 0 && n++ <= miniFat.size && out.size() < size) {
            val off = s.toLong() * miniSize
            if (off + miniSize > miniStream.size) break
            out.write(miniStream, off.toInt(), miniSize)
            s = if (s < miniFat.size) miniFat[s] else -2
        }
        val r = out.toByteArray()
        return if (r.size > size) r.copyOf(size) else r
    }

    fun stream(name: String): ByteArray? {
        val e = entries.firstOrNull { it.type == 2 && it.name.equals(name, true) } ?: return null
        return if (e.size < miniCutoff) {
            readMini(e.start, e.size.toInt())
        } else {
            val raw = readChain(e.start)
            if (raw.size > e.size) raw.copyOf(e.size.toInt()) else raw
        }
    }
}

/**
 * Best-effort text extraction from Word 97-2003 .doc (FIB -> CLX piece table).
 * Formatting, images and tables structure are NOT recovered; text only.
 */
object DocReader {
    fun toHtml(bytes: ByteArray): String {
        val ole = Ole(bytes)
        val word = ole.stream("WordDocument") ?: throw IOException("Fluxo WordDocument ausente (não é um .doc do Word)")
        if (word.size < 0x9A || u16(word, 0) != 0xA5EC) throw IOException("Cabeçalho FIB inválido")
        val flags = u16(word, 0x0A)
        if (flags and 0x0100 != 0) throw IOException("Documento .doc protegido por senha não é suportado")
        val tableName = if (flags and 0x0200 != 0) "1Table" else "0Table"
        val table = ole.stream(tableName) ?: throw IOException("Fluxo $tableName ausente")

        val csw = u16(word, 0x20)
        val lwStart = 0x20 + 2 + csw * 2
        val cslw = u16(word, lwStart)
        val ccpText = i32(word, lwStart + 2 + 3 * 4)
        val fcStart = lwStart + 2 + cslw * 4
        val cbFcLcb = u16(word, fcStart)
        val pairs = fcStart + 2
        if (cbFcLcb < 34) throw IOException("FIB curto demais")
        val fcClx = i32(word, pairs + 33 * 8)
        val lcbClx = i32(word, pairs + 33 * 8 + 4)
        if (fcClx < 0 || lcbClx <= 0 || fcClx.toLong() + lcbClx > table.size) throw IOException("CLX fora dos limites")
        val clx = table.copyOfRange(fcClx, fcClx + lcbClx)

        var p = 0
        while (p < clx.size && (clx[p].toInt() and 0xFF) == 1) p += 3 + u16(clx, p + 1)
        if (p >= clx.size || clx[p].toInt() != 2) throw IOException("Tabela de peças (piece table) ausente")
        val lcb = i32(clx, p + 1)
        val plc = p + 5
        val n = (lcb - 4) / 12
        if (n <= 0) throw IOException("Piece table vazia")

        val limit = if (ccpText > 0) ccpText else Int.MAX_VALUE
        val raw = StringBuilder()
        val cp1252 = Charset.forName("windows-1252")
        for (i in 0 until n) {
            val cpStart = i32(clx, plc + 4 * i)
            val cpEnd = minOf(i32(clx, plc + 4 * (i + 1)), limit)
            if (cpStart >= limit) break
            val count = cpEnd - cpStart
            if (count <= 0) continue
            val fcRaw = i32(clx, plc + 4 * (n + 1) + 8 * i + 2)
            val compressed = (fcRaw and 0x40000000) != 0
            val fc = fcRaw and 0x3FFFFFFF
            if (compressed) {
                val off = fc / 2
                if (off < 0 || off.toLong() + count > word.size) break
                raw.append(String(word, off, count, cp1252))
            } else {
                if (fc < 0 || fc.toLong() + count * 2L > word.size) break
                raw.append(String(word, fc, count * 2, Charsets.UTF_16LE))
            }
        }
        return Sanitizer.clean(toParagraphs(raw))
    }

    private fun toParagraphs(raw: CharSequence): String {
        val html = StringBuilder()
        val para = StringBuilder()
        val fields = ArrayList<Boolean>() // true = inside field code (hidden)

        fun flush() {
            html.append("<p>")
            if (para.isEmpty()) html.append("<br>") else html.append(TextUtil.esc(para).replace('\u000B'.toString(), "<br>"))
            html.append("</p>")
            para.setLength(0)
        }

        for (ch in raw) {
            val code = ch.code
            if (code == 0x13) { fields.add(true); continue }
            if (code == 0x14) { if (fields.isNotEmpty()) fields[fields.lastIndex] = false; continue }
            if (code == 0x15) { if (fields.isNotEmpty()) fields.removeAt(fields.lastIndex); continue }
            if (fields.any { it }) continue
            when (code) {
                0x0D -> flush()
                0x07 -> para.append('\t')
                0x0B -> para.append('\u000B')
                0x0C -> {
                    flush()
                    html.append("<hr class=\"pb\">")
                }
                0x1E -> para.append('-')
                else -> if (code >= 0x20 || code == 0x09) para.append(ch)
            }
        }
        if (para.isNotEmpty()) flush()
        return html.toString()
    }
}
