package com.offlinereader

import android.util.Base64
import org.w3c.dom.Element
import java.io.IOException

object DocxReader {
    private class Ctx(
        val zip: Map<String, ByteArray>,
        val rels: Map<String, String>,
        val styles: Map<String, String>,
        val numbering: Map<String, Array<String>>,
    ) {
        val counters = HashMap<String, IntArray>()
        val budget = LongArray(1)
    }

    private val HEADING = Regex("heading\\s*([1-9])")
    private val HEX = Regex("[0-9A-Fa-f]{6}")

    fun toHtml(bytes: ByteArray): String {
        val z = Zip.readAll(bytes)
        val docBytes = z["word/document.xml"] ?: throw IOException("word/document.xml ausente (não é um .docx válido)")
        val ctx = Ctx(
            z,
            Xml.rels(z["word/_rels/document.xml.rels"]),
            styleNames(z["word/styles.xml"]),
            numbering(z["word/numbering.xml"]),
        )
        val body = Xml.dom(docBytes).documentElement.first("w:body") ?: throw IOException("w:body ausente")
        val sb = StringBuilder()
        blocks(body, ctx, sb)
        return Sanitizer.clean(sb.toString())
    }

    private fun styleNames(b: ByteArray?): Map<String, String> {
        if (b == null) return emptyMap()
        val out = HashMap<String, String>()
        for (s in Xml.dom(b).documentElement.elems()) {
            if (s.tagName == "w:style") {
                val n = s.first("w:name")?.getAttribute("w:val")
                if (n != null) out[s.getAttribute("w:styleId")] = n
            }
        }
        return out
    }

    private fun numbering(b: ByteArray?): Map<String, Array<String>> {
        if (b == null) return emptyMap()
        val root = Xml.dom(b).documentElement
        val abs = HashMap<String, Array<String>>()
        for (a in root.elems()) {
            if (a.tagName != "w:abstractNum") continue
            val fmts = Array(9) { "decimal" }
            for (l in a.elems()) {
                if (l.tagName != "w:lvl") continue
                val il = l.getAttribute("w:ilvl").toIntOrNull() ?: continue
                if (il !in 0..8) continue
                fmts[il] = l.first("w:numFmt")?.getAttribute("w:val") ?: "decimal"
            }
            abs[a.getAttribute("w:abstractNumId")] = fmts
        }
        val out = HashMap<String, Array<String>>()
        for (n in root.elems()) {
            if (n.tagName != "w:num") continue
            val id = n.first("w:abstractNumId")?.getAttribute("w:val") ?: continue
            val f = abs[id] ?: continue
            out[n.getAttribute("w:numId")] = f
        }
        return out
    }

    private fun blocks(parent: Element, c: Ctx, sb: StringBuilder) {
        for (e in parent.elems()) {
            when (e.tagName) {
                "w:p" -> paragraph(e, c, sb)
                "w:tbl" -> table(e, c, sb)
                "w:sdt" -> e.first("w:sdtContent")?.let { blocks(it, c, sb) }
            }
        }
    }

    private fun table(t: Element, c: Ctx, sb: StringBuilder) {
        sb.append("<table>")
        for (tr in t.elems()) {
            if (tr.tagName != "w:tr") continue
            sb.append("<tr>")
            for (tc in tr.elems()) {
                if (tc.tagName != "w:tc") continue
                val span = tc.first("w:tcPr")?.first("w:gridSpan")?.getAttribute("w:val")?.toIntOrNull() ?: 1
                sb.append(if (span > 1) "<td colspan=\"$span\">" else "<td>")
                val cell = StringBuilder()
                blocks(tc, c, cell)
                sb.append(if (cell.isEmpty()) "<br>" else cell.toString())
                sb.append("</td>")
            }
            sb.append("</tr>")
        }
        sb.append("</table>")
    }

    private fun paragraph(p: Element, c: Ctx, sb: StringBuilder) {
        val pPr = p.first("w:pPr")
        val styleId = pPr?.first("w:pStyle")?.getAttribute("w:val") ?: ""
        val sname = (c.styles[styleId] ?: styleId).lowercase()
        var tag = "p"
        HEADING.find(sname)?.let { tag = "h" + minOf(6, it.groupValues[1].toInt()) }
        if (sname == "title") tag = "h1"
        if (sname == "subtitle") tag = "h2"

        val css = StringBuilder()
        when (pPr?.first("w:jc")?.getAttribute("w:val")) {
            "center" -> css.append("text-align:center;")
            "right", "end" -> css.append("text-align:right;")
            "both", "distribute" -> css.append("text-align:justify;")
        }

        var prefix = ""
        val numPr = pPr?.first("w:numPr")
        val numId = numPr?.first("w:numId")?.getAttribute("w:val")
        if (numId != null && numId != "0") {
            val lvl = (numPr?.first("w:ilvl")?.getAttribute("w:val")?.toIntOrNull() ?: 0).coerceIn(0, 8)
            val fmt = c.numbering[numId]?.get(lvl) ?: "bullet"
            prefix = if (fmt == "bullet" || fmt == "none") {
                "\u2022 "
            } else {
                val arr = c.counters.getOrPut(numId) { IntArray(9) }
                arr[lvl]++
                for (k in lvl + 1 until 9) arr[k] = 0
                numberLabel(fmt, arr[lvl]) + " "
            }
            css.append("margin-left:${(lvl + 1) * 28}px;text-indent:-18px;")
        }

        val inner = StringBuilder()
        runs(p, c, inner)
        sb.append('<').append(tag)
        if (css.isNotEmpty()) sb.append(" style=\"").append(css).append('"')
        sb.append('>')
        if (prefix.isNotEmpty()) sb.append(prefix)
        if (inner.isEmpty()) sb.append("<br>") else sb.append(inner.toString())
        sb.append("</").append(tag).append('>')
    }

    private fun numberLabel(fmt: String, n: Int): String = when (fmt) {
        "lowerLetter" -> letter(n, 'a') + "."
        "upperLetter" -> letter(n, 'A') + "."
        else -> "$n."
    }

    private fun letter(n: Int, base: Char): String {
        var i = n
        val sb = StringBuilder()
        while (i > 0) {
            val m = (i - 1) % 26
            sb.insert(0, (base.code + m).toChar())
            i = (i - 1) / 26
        }
        return sb.toString()
    }

    private fun runs(parent: Element, c: Ctx, sb: StringBuilder) {
        for (e in parent.elems()) {
            when (e.tagName) {
                "w:r" -> run(e, c, sb)
                "w:hyperlink", "w:ins", "w:smartTag", "w:sdt", "w:sdtContent", "w:fldSimple", "w:customXml" -> runs(e, c, sb)
            }
        }
    }

    private fun flag(rPr: Element?, tag: String): Boolean {
        val e = rPr?.first(tag) ?: return false
        val v = e.getAttribute("w:val")
        return v != "0" && v != "false" && v != "off"
    }

    private fun run(r: Element, c: Ctx, sb: StringBuilder) {
        val rPr = r.first("w:rPr")
        val inner = StringBuilder()
        for (e in r.elems()) {
            when (e.tagName) {
                "w:t" -> inner.append(TextUtil.esc(e.textContent))
                "w:tab" -> inner.append("&emsp;")
                "w:br", "w:cr" ->
                    if (e.getAttribute("w:type") == "page") inner.append("<hr class=\"pb\">") else inner.append("<br>")
                "w:drawing", "w:pict", "mc:AlternateContent" -> image(e, c, inner)
            }
        }
        if (inner.isEmpty()) return
        var s = inner.toString()

        val css = StringBuilder()
        val color = rPr?.first("w:color")?.getAttribute("w:val") ?: ""
        if (HEX.matches(color)) css.append("color:#").append(color).append(';')
        val sz = rPr?.first("w:sz")?.getAttribute("w:val")?.toIntOrNull()
        if (sz != null && sz in 2..400) css.append("font-size:").append(sz / 2.0).append("pt;")
        if (css.isNotEmpty()) s = "<span style=\"$css\">$s</span>"

        if (flag(rPr, "w:b")) s = "<b>$s</b>"
        if (flag(rPr, "w:i")) s = "<i>$s</i>"
        val u = rPr?.first("w:u")?.getAttribute("w:val")
        if (rPr?.first("w:u") != null && u != "none") s = "<u>$s</u>"
        if (flag(rPr, "w:strike")) s = "<s>$s</s>"
        val hl = rPr?.first("w:highlight")?.getAttribute("w:val")
        if (hl != null && hl != "none") s = "<mark>$s</mark>"
        when (rPr?.first("w:vertAlign")?.getAttribute("w:val")) {
            "superscript" -> s = "<sup>$s</sup>"
            "subscript" -> s = "<sub>$s</sub>"
        }
        sb.append(s)
    }

    private fun image(e: Element, c: Ctx, out: StringBuilder) {
        for (blip in e.descendants("blip")) {
            val id = blip.getAttribute("r:embed")
            val target = c.rels[id] ?: continue
            val uri = Imgs.dataUri(c.zip, resolvePath("word", target), c.budget)
            if (uri == null) {
                out.append("[imagem omitida]")
                continue
            }
            val cx = e.descendants("extent").firstOrNull()?.getAttribute("cx")?.toLongOrNull()
            val w = cx?.let { it / 9525 }
            out.append("<img src=\"").append(uri).append('"')
            if (w != null && w in 8L..3000L) out.append(" style=\"width:").append(w).append("px;max-width:100%;height:auto\"")
            out.append('>')
        }
    }
}
