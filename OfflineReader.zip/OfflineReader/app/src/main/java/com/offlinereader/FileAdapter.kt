package com.offlinereader

import android.graphics.Color
import android.content.res.ColorStateList
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.util.Date

class FileAdapter(
    private val onClick: (FileItem) -> Unit,
    private val onLongClick: (FileItem) -> Unit,
) : ListAdapter<FileItem, FileAdapter.VH>(Diff) {

    class VH(v: android.view.View) : RecyclerView.ViewHolder(v) {
        val badge: TextView = v.findViewById(R.id.badge)
        val name: TextView = v.findViewById(R.id.name)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    private object Diff : DiffUtil.ItemCallback<FileItem>() {
        override fun areItemsTheSame(a: FileItem, b: FileItem) = a.uri == b.uri
        override fun areContentsTheSame(a: FileItem, b: FileItem) = a == b
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val item = getItem(position)
        val ext = item.ext
        h.badge.text = ext.uppercase().take(5)
        h.badge.backgroundTintList = ColorStateList.valueOf(FileTypes.badgeColor(ext))
        h.badge.setTextColor(Color.WHITE)
        h.name.text = item.name
        val ctx = h.itemView.context
        val date = if (item.modified > 0) DateFormat.getMediumDateFormat(ctx).format(Date(item.modified)) else "data desconhecida"
        val size = if (item.size > 0) Formatter.formatShortFileSize(ctx, item.size) else "—"
        h.meta.text = "$size · $date"
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnLongClickListener {
            onLongClick(item)
            true
        }
    }
}
