package com.offlinereader

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.text.HtmlCompat
import org.jsoup.Jsoup
import java.io.ByteArrayOutputStream

/** Creates a text PDF (A4, 56pt margins) with the platform PdfDocument. Images are not embedded. */
object PdfWriter {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 56

    fun fromHtml(html: String): ByteArray {
        val d = Jsoup.parseBodyFragment(html)
        d.select("img").remove()
        d.select("td,th").after(" \u00A0|\u00A0 ")
        d.select("tr").after("<br>")
        return fromText(HtmlCompat.fromHtml(d.body().html(), HtmlCompat.FROM_HTML_MODE_LEGACY))
    }

    fun fromText(text: CharSequence): ByteArray {
        val doc = PdfDocument()
        try {
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 11f
                color = Color.BLACK
                typeface = Typeface.SERIF
            }
            val width = PAGE_W - 2 * MARGIN
            val contentH = PAGE_H - 2 * MARGIN
            val src: CharSequence = if (text.isEmpty()) " " else text
            val layout = StaticLayout.Builder.obtain(src, 0, src.length, paint, width)
                .setLineSpacing(2f, 1f)
                .setIncludePad(false)
                .build()

            var line = 0
            var pageNo = 1
            while (line < layout.lineCount) {
                val pageTop = layout.getLineTop(line)
                var end = line
                while (end < layout.lineCount && layout.getLineBottom(end) - pageTop <= contentH) end++
                if (end == line) end = line + 1
                val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNo).create())
                val c = page.canvas
                c.save()
                c.translate(MARGIN.toFloat(), (MARGIN - pageTop).toFloat())
                c.clipRect(0f, pageTop.toFloat(), width.toFloat(), layout.getLineBottom(end - 1).toFloat())
                layout.draw(c)
                c.restore()
                doc.finishPage(page)
                line = end
                pageNo++
            }
            val out = ByteArrayOutputStream()
            doc.writeTo(out)
            return out.toByteArray()
        } finally {
            doc.close()
        }
    }
}
