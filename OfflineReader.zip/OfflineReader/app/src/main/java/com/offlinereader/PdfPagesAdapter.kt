package com.offlinereader

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Renders PDF pages as bitmaps. [scope] MUST run on a single thread (PdfRenderer allows one open page at a time).
 */
class PdfPagesAdapter(
    private val renderer: PdfRenderer,
    private val scope: CoroutineScope,
    private val widthPx: () -> Int,
) : RecyclerView.Adapter<PdfPagesAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img) {
        var job: Job? = null
    }

    override fun getItemCount(): Int = renderer.pageCount

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context)
        val gap = (8 * parent.resources.displayMetrics.density).toInt()
        iv.layoutParams = RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = gap }
        iv.adjustViewBounds = true
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.setBackgroundColor(Color.WHITE)
        return VH(iv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.job?.cancel()
        holder.img.setImageBitmap(null)
        val w = widthPx().coerceAtLeast(320)
        holder.img.minimumHeight = (w * 1.4f).toInt()
        holder.job = scope.launch {
            var result: Bitmap? = null
            try {
                val page = renderer.openPage(position)
                try {
                    val ph = (w.toLong() * page.height / page.width).toInt().coerceIn(1, 8000)
                    val b = Bitmap.createBitmap(w, ph, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    page.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    result = b
                } finally {
                    page.close()
                }
            } catch (e: Exception) {
                result = null
            }
            val bmp = result
            withContext(Dispatchers.Main) {
                if (isActive && bmp != null) {
                    holder.img.minimumHeight = 0
                    holder.img.setImageBitmap(bmp)
                }
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        holder.job?.cancel()
        holder.img.setImageBitmap(null)
    }
}
