# Leitor Offline (OfflineReader)

Build (Android Studio Koala/Ladybug or newer, JDK 17):
1. File > Open > pasta OfflineReader. Aguarde o Gradle Sync (precisa de internet SÓ nessa etapa, para baixar dependências).
2. Build > Build Bundle(s) / APK(s) > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
   (CLI: gere o wrapper uma vez com `gradle wrapper --gradle-version 8.7`, depois `./gradlew assembleDebug`)
3. Instale o APK (ative "instalar apps desconhecidos"). O app não tem permissão INTERNET.
